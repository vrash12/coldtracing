<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['role']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['role']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $normalizedRole = strtolower(str_replace(' ', '-', (string) ($role ?: 'No role')));
    $roleIcon = match ($normalizedRole) {
        'administrator' => 'bi-shield-lock-fill',
        'driver' => 'bi-truck-front-fill',
        'receiver' => 'bi-box2-heart-fill',
        default => 'bi-person-fill',
    };
?>

<span class="ct-role ct-role-<?php echo e($normalizedRole); ?>">
    <i class="bi <?php echo e($roleIcon); ?>"></i>
    <?php echo e($role ?: 'No role'); ?>

</span>
<?php /**PATH C:\Users\MAURICIO\Documents\coldtrace\resources\views\components\dashboard\role-badge.blade.php ENDPATH**/ ?>