

<?php $__env->startSection('title', 'Order Details'); ?>

<?php $__env->startSection('content'); ?>

<div class="customer-order-show-page">

    <div class="show-header">
        <div>
            <span class="eyebrow">Order Details</span>
            <h1><?php echo e($order->order_code); ?></h1>
            <p>Review your order request, delivery address, products, and current status.</p>
        </div>

        <div class="header-actions">
            <a href="<?php echo e(route('customer.orders.index')); ?>" class="secondary-button">
                Back to Orders
            </a>

            <?php if($canEdit): ?>
                <a href="<?php echo e(route('customer.orders.edit', $order)); ?>" class="primary-button">
                    Edit Order
                </a>
            <?php endif; ?>
        </div>
    </div>

    <?php if(session('success')): ?>
        <div class="flash-message success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="flash-message error"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    <section class="details-panel">
        <div class="order-profile">
            <div class="order-icon">
                <i class="bi bi-bag-check"></i>
            </div>

            <div>
                <h2><?php echo e($order->order_code); ?></h2>
                <p><?php echo e($order->orderItems->count()); ?> product item(s)</p>

                <span class="status-badge status-<?php echo e($order->status); ?>">
                    <?php echo e(ucfirst(str_replace('_', ' ', $order->status))); ?>

                </span>
            </div>
        </div>

        <div class="details-grid">
            <div class="detail-card">
                <span>Status</span>
                <strong><?php echo e(ucfirst(str_replace('_', ' ', $order->status))); ?></strong>
                <small>
                    <?php if($order->status === 'pending'): ?>
                        Waiting for administrator review.
                    <?php elseif($order->status === 'approved'): ?>
                        Approved and waiting for assignment.
                    <?php elseif($order->status === 'assigned'): ?>
                        Assigned to delivery resources.
                    <?php elseif($order->status === 'in_transit'): ?>
                        Your order is currently in transit.
                    <?php elseif($order->status === 'delivered'): ?>
                        Delivery completed.
                    <?php else: ?>
                        This order has been cancelled.
                    <?php endif; ?>
                </small>
            </div>

            <div class="detail-card">
                <span>Created At</span>
                <strong><?php echo e($order->created_at?->format('M d, Y')); ?></strong>
                <small><?php echo e($order->created_at?->format('h:i A')); ?></small>
            </div>

            <div class="detail-card">
                <span>Expected Delivery</span>
                <strong><?php echo e($order->expected_delivery_at?->format('M d, Y') ?? 'Not set'); ?></strong>
                <small><?php echo e($order->expected_delivery_at?->format('h:i A') ?? 'No preferred time provided'); ?></small>
            </div>

            <div class="detail-card">
                <span>Delivery Address</span>
                <strong><?php echo e($order->delivery_address); ?></strong>
                <small><?php echo e($order->delivery_lat); ?>, <?php echo e($order->delivery_lng); ?></small>
            </div>

            <div class="detail-card full-width">
                <span>Products</span>

                <div class="product-list">
                    <?php $__empty_1 = true; $__currentLoopData = $order->orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="product-row">
                            <div>
                                <strong><?php echo e($item->product?->name ?? 'N/A'); ?></strong>
                                <small>
                                    Safe range:
                                    <?php echo e($item->product?->min_temp ?? 'N/A'); ?>°C
                                    to
                                    <?php echo e($item->product?->max_temp ?? 'N/A'); ?>°C
                                </small>
                            </div>

                            <em><?php echo e($item->quantity); ?> <?php echo e($item->unit); ?></em>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="muted">No products listed.</p>
                    <?php endif; ?>
                </div>
            </div>

            <div class="detail-card full-width">
                <span>Handling Notes</span>
                <strong><?php echo e($order->notes ?: 'No notes provided.'); ?></strong>
            </div>
        </div>
    </section>

    <?php if($canCancel || $canDelete): ?>
        <section class="danger-panel">
            <div>
                <h2>Order Actions</h2>
                <p>
                    Pending orders can be deleted. Pending or approved orders can be cancelled.
                    Once an order is assigned or in transit, please contact the administrator.
                </p>
            </div>

            <div class="danger-actions">
                <?php if($canCancel): ?>
                    <form
                        method="POST"
                        action="<?php echo e(route('customer.orders.cancel', $order)); ?>"
                        onsubmit="return confirm('Cancel this order?');"
                    >
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PATCH'); ?>

                        <button type="submit" class="cancel-button">
                            Cancel Order
                        </button>
                    </form>
                <?php endif; ?>

                <?php if($canDelete): ?>
                    <form
                        method="POST"
                        action="<?php echo e(route('customer.orders.destroy', $order)); ?>"
                        onsubmit="return confirm('Delete this pending order? This cannot be undone.');"
                    >
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>

                        <button type="submit" class="delete-button">
                            Delete Order
                        </button>
                    </form>
                <?php endif; ?>
            </div>
        </section>
    <?php endif; ?>

</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>
    .customer-order-show-page {
        display: flex;
        flex-direction: column;
        gap: 20px;
    }

    .show-header {
        display: flex;
        justify-content: space-between;
        align-items: flex-end;
        gap: 24px;
        padding: 24px;
        border-radius: 24px;
        background:
            radial-gradient(circle at top left, rgba(34, 211, 238, 0.18), transparent 35%),
            linear-gradient(135deg, #ffffff, #f8fafc);
        border: 1px solid #e5e7eb;
        box-shadow: 0 12px 30px rgba(15, 23, 42, 0.07);
    }

    .eyebrow {
        display: inline-flex;
        background: #ecfeff;
        color: #0891b2;
        border: 1px solid #cffafe;
        border-radius: 999px;
        padding: 7px 12px;
        font-size: 12px;
        font-weight: 800;
        margin-bottom: 12px;
    }

    .show-header h1 {
        margin: 0;
        color: #0f172a;
        font-size: 34px;
        font-weight: 900;
        letter-spacing: -0.05em;
    }

    .show-header p {
        margin: 8px 0 0;
        color: #64748b;
        line-height: 1.6;
    }

    .header-actions,
    .danger-actions {
        display: flex;
        gap: 10px;
        flex-wrap: wrap;
    }

    .primary-button,
    .secondary-button,
    .cancel-button,
    .delete-button {
        min-height: 44px;
        border: none;
        border-radius: 999px;
        padding: 0 18px;
        text-decoration: none;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        font-weight: 900;
    }

    .primary-button {
        background: #2563eb;
        color: #ffffff;
    }

    .secondary-button {
        background: #f1f5f9;
        color: #475569;
    }

    .flash-message {
        padding: 14px 16px;
        border-radius: 16px;
        font-size: 14px;
        font-weight: 800;
    }

    .flash-message.success {
        background: #f0fdf4;
        color: #15803d;
        border: 1px solid #bbf7d0;
    }

    .flash-message.error {
        background: #fef2f2;
        color: #b91c1c;
        border: 1px solid #fecaca;
    }

    .details-panel,
    .danger-panel {
        background: #ffffff;
        border: 1px solid #e5e7eb;
        border-radius: 24px;
        padding: 22px;
        box-shadow: 0 12px 30px rgba(15, 23, 42, 0.07);
    }

    .order-profile {
        display: flex;
        align-items: center;
        gap: 18px;
        margin-bottom: 24px;
    }

    .order-icon {
        width: 72px;
        height: 72px;
        border-radius: 24px;
        background: linear-gradient(135deg, #2563eb, #06b6d4);
        color: #ffffff;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 30px;
        flex-shrink: 0;
    }

    .order-profile h2 {
        margin: 0;
        color: #0f172a;
        font-size: 26px;
        font-weight: 900;
    }

    .order-profile p {
        margin: 6px 0 12px;
        color: #64748b;
    }

    .status-badge {
        display: inline-flex;
        min-height: 30px;
        padding: 7px 11px;
        border-radius: 999px;
        font-size: 12px;
        font-weight: 900;
    }

    .status-pending {
        background: #fffbeb;
        color: #d97706;
    }

    .status-approved {
        background: #dbeafe;
        color: #2563eb;
    }

    .status-assigned {
        background: #ecfeff;
        color: #0891b2;
    }

    .status-in_transit {
        background: #f5f3ff;
        color: #7c3aed;
    }

    .status-delivered {
        background: #f0fdf4;
        color: #16a34a;
    }

    .status-cancelled {
        background: #fef2f2;
        color: #dc2626;
    }

    .details-grid {
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 16px;
    }

    .detail-card {
        background: #f8fafc;
        border: 1px solid #e5e7eb;
        border-radius: 18px;
        padding: 16px;
    }

    .detail-card.full-width {
        grid-column: 1 / -1;
    }

    .detail-card span {
        display: block;
        color: #64748b;
        font-size: 12px;
        font-weight: 900;
        margin-bottom: 8px;
    }

    .detail-card strong {
        display: block;
        color: #0f172a;
        font-size: 14px;
        line-height: 1.5;
    }

    .detail-card small {
        display: block;
        color: #94a3b8;
        margin-top: 6px;
    }

    .product-list {
        display: flex;
        flex-direction: column;
        gap: 10px;
    }

    .product-row {
        display: flex;
        justify-content: space-between;
        gap: 14px;
        background: #ffffff;
        border: 1px solid #e5e7eb;
        border-radius: 14px;
        padding: 13px;
    }

    .product-row em {
        font-style: normal;
        color: #2563eb;
        font-weight: 900;
        white-space: nowrap;
    }

    .muted {
        color: #94a3b8;
    }

    .danger-panel {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 18px;
        border-color: #fecaca;
    }

    .danger-panel h2 {
        margin: 0;
        color: #0f172a;
        font-size: 20px;
        font-weight: 900;
    }

    .danger-panel p {
        margin: 6px 0 0;
        color: #64748b;
        font-size: 13px;
        line-height: 1.5;
    }

    .cancel-button {
        background: #fffbeb;
        color: #d97706;
    }

    .delete-button {
        background: #fef2f2;
        color: #dc2626;
    }

    @media (max-width: 760px) {
        .show-header,
        .danger-panel,
        .order-profile {
            flex-direction: column;
            align-items: flex-start;
        }

        .header-actions,
        .header-actions a,
        .danger-actions,
        .danger-actions form,
        .danger-actions button {
            width: 100%;
        }

        .details-grid {
            grid-template-columns: 1fr;
        }

        .product-row {
            flex-direction: column;
        }
    }
</style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\MAURICIO\Documents\coldtrace\resources\views\customer\orders\show.blade.php ENDPATH**/ ?>