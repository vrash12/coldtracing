

<?php $__env->startSection('title', 'Create Order'); ?>

<?php $__env->startSection('content'); ?>

<div class="customer-order-page">

    <div class="customer-order-header">
        <div>
            <span class="eyebrow">Customer Order Request</span>
            <h1>Create New Order</h1>
            <p>Select your products, delivery schedule, and delivery location.</p>
        </div>

        <a href="<?php echo e(route('customer.orders.index')); ?>" class="secondary-button">
            Back to Orders
        </a>
    </div>

    <?php if($errors->any()): ?>
        <div class="flash-message error">
            Please check the form and correct the highlighted fields.
        </div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('customer.orders.store')); ?>" class="customer-order-form">
        <?php echo csrf_field(); ?>

        <?php echo $__env->make('customer.orders.partials.form', [
            'order' => null,
            'customer' => $customer,
            'products' => $products,
            'googleMapsApiKey' => $googleMapsApiKey,
            'buttonText' => 'Submit Order Request',
            'cancelRoute' => route('customer.orders.index'),
        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </form>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\MAURICIO\Documents\coldtrace\resources\views\customer\orders\create.blade.php ENDPATH**/ ?>