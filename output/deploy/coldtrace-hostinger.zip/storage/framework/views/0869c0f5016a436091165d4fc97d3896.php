

<?php $__env->startSection('title', 'Create User'); ?>

<?php $__env->startSection('content'); ?>

<div class="page-header">
    <div>
        <span class="eyebrow">Administrator module</span>
        <h1>Create User</h1>
        <p>Add a new ColdTrace account and assign a system role.</p>
    </div>

    <a href="<?php echo e(route('users.index')); ?>" class="secondary-button">
        Back to Users
    </a>
</div>

<div class="form-panel">
    <form method="POST" action="<?php echo e(route('users.store')); ?>" class="user-form">
        <?php echo csrf_field(); ?>

        <?php echo $__env->make('admin.users.partials.form', [
            'user' => null,
            'roles' => $roles,
            'buttonText' => 'Create User',
            'isEdit' => false,
        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </form>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<?php echo $__env->make('admin.users.partials.styles', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\MAURICIO\Documents\coldtrace\resources\views\admin\users\create.blade.php ENDPATH**/ ?>