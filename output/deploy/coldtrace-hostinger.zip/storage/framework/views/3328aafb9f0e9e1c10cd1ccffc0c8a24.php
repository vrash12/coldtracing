<?php $__env->startSection('title', 'Driver Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<?php
    $assignedTruck = $driver->assignedTruck;
?>

<div class="ct-dashboard">
    <section class="ct-hero">
        <div class="ct-hero-copy">
            <span class="ct-eyebrow"><span class="ct-eyebrow-dot"></span>Driver workspace</span>
            <h1>Your next delivery is the priority.</h1>
            <p>Start assigned trips, monitor the cargo, and open navigation without sorting through repeated history and status panels.</p>
            <div class="ct-hero-meta">
                <span><i class="bi bi-person-circle"></i><?php echo e($driver->name); ?></span>
                <span><i class="bi bi-truck-front-fill"></i><?php echo e($assignedTruck?->plate_number ?? 'No truck assigned'); ?></span>
                <span><i class="bi bi-broadcast-pin"></i>Last cargo update: <?php echo e($latestTelemetryAt?->diffForHumans() ?? 'No readings yet'); ?></span>
            </div>
        </div>
        <div class="ct-actions">
            <a href="<?php echo e(route('driver.orders.index')); ?>" class="ct-button ct-button-primary"><i class="bi bi-map-fill"></i>Plan my route</a>
        </div>
    </section>

    <section class="ct-metrics" aria-label="Driver work summary">
        <?php if (isset($component)) { $__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.metric','data' => ['label' => 'Ready to start','value' => $pendingTrips,'detail' => 'Trips awaiting departure','icon' => 'bi-play-circle-fill','tone' => 'amber','href' => route('driver.orders.index', ['status' => 'assigned'])]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.metric'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Ready to start','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($pendingTrips),'detail' => 'Trips awaiting departure','icon' => 'bi-play-circle-fill','tone' => 'amber','href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('driver.orders.index', ['status' => 'assigned']))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd)): ?>
<?php $attributes = $__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd; ?>
<?php unset($__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd)): ?>
<?php $component = $__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd; ?>
<?php unset($__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.metric','data' => ['label' => 'Active trips','value' => $activeTrips,'detail' => 'Deliveries currently underway','icon' => 'bi-truck-front-fill','tone' => 'cyan','href' => route('driver.orders.index', ['status' => 'in_transit'])]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.metric'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Active trips','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($activeTrips),'detail' => 'Deliveries currently underway','icon' => 'bi-truck-front-fill','tone' => 'cyan','href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('driver.orders.index', ['status' => 'in_transit']))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd)): ?>
<?php $attributes = $__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd; ?>
<?php unset($__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd)): ?>
<?php $component = $__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd; ?>
<?php unset($__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.metric','data' => ['label' => 'Assigned orders','value' => $assignedOrders,'detail' => 'Current delivery workload','icon' => 'bi-box-seam-fill','tone' => 'blue','href' => route('driver.orders.index')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.metric'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Assigned orders','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($assignedOrders),'detail' => 'Current delivery workload','icon' => 'bi-box-seam-fill','tone' => 'blue','href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('driver.orders.index'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd)): ?>
<?php $attributes = $__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd; ?>
<?php unset($__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd)): ?>
<?php $component = $__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd; ?>
<?php unset($__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.metric','data' => ['label' => 'Unread updates','value' => $unreadNotificationCount,'detail' => 'New assignment notifications','icon' => 'bi-bell-fill','tone' => $unreadNotificationCount > 0 ? 'violet' : 'green']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.metric'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Unread updates','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($unreadNotificationCount),'detail' => 'New assignment notifications','icon' => 'bi-bell-fill','tone' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($unreadNotificationCount > 0 ? 'violet' : 'green')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd)): ?>
<?php $attributes = $__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd; ?>
<?php unset($__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd)): ?>
<?php $component = $__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd; ?>
<?php unset($__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd); ?>
<?php endif; ?>
    </section>

    <div class="ct-grid-main">
        <section class="ct-panel">
            <header class="ct-panel-header">
                <div class="ct-panel-heading">
                    <span class="ct-panel-icon cyan"><i class="bi bi-signpost-2-fill"></i></span>
                    <div class="ct-panel-title"><small>Work queue</small><h2>Current deliveries</h2></div>
                </div>
                <a href="<?php echo e(route('driver.orders.index')); ?>" class="ct-panel-link">All assigned orders <i class="bi bi-arrow-right"></i></a>
            </header>
            <div class="ct-panel-body">
                <div class="ct-delivery-list">
                    <?php $__empty_1 = true; $__currentLoopData = $currentTrips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php
                            $reading = $trip->latestTelemetry;
                            $temperature = $reading?->temperature !== null ? (float) $reading->temperature : null;
                            $minimum = $trip->product?->min_temp !== null ? (float) $trip->product->min_temp : null;
                            $maximum = $trip->product?->max_temp !== null ? (float) $trip->product->max_temp : null;

                            if ($temperature === null || $minimum === null || $maximum === null) {
                                $conditionClass = 'neutral';
                                $conditionLabel = 'No current reading';
                                $conditionIcon = 'bi-dash-circle';
                            } elseif ($temperature > $maximum) {
                                $conditionClass = 'danger';
                                $conditionLabel = number_format($temperature, 1) . ' °C · Too high';
                                $conditionIcon = 'bi-thermometer-high';
                            } elseif ($temperature < $minimum) {
                                $conditionClass = 'warning';
                                $conditionLabel = number_format($temperature, 1) . ' °C · Too low';
                                $conditionIcon = 'bi-thermometer-low';
                            } else {
                                $conditionClass = 'safe';
                                $conditionLabel = number_format($temperature, 1) . ' °C · Safe';
                                $conditionIcon = 'bi-shield-check';
                            }

                            $destination = $trip->destination_lat !== null && $trip->destination_lng !== null
                                ? $trip->destination_lat . ',' . $trip->destination_lng
                                : $trip->destination_address;
                            $navigationUrl = $destination
                                ? 'https://www.google.com/maps/dir/?api=1&destination=' . urlencode($destination) . '&travelmode=driving'
                                : null;
                        ?>
                        <article class="ct-delivery">
                            <div class="ct-delivery-top">
                                <div class="ct-delivery-title">
                                    <strong><?php echo e($trip->order?->order_code ?? 'Trip #' . $trip->id); ?></strong>
                                    <span><i class="bi bi-geo-alt-fill"></i> <?php echo e($trip->destination_address ?? 'Destination not set'); ?></span>
                                </div>
                                <?php if (isset($component)) { $__componentOriginal41cda017b93539193a6609497ccd9474 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal41cda017b93539193a6609497ccd9474 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.status-badge','data' => ['status' => $trip->status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($trip->status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal41cda017b93539193a6609497ccd9474)): ?>
<?php $attributes = $__attributesOriginal41cda017b93539193a6609497ccd9474; ?>
<?php unset($__attributesOriginal41cda017b93539193a6609497ccd9474); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal41cda017b93539193a6609497ccd9474)): ?>
<?php $component = $__componentOriginal41cda017b93539193a6609497ccd9474; ?>
<?php unset($__componentOriginal41cda017b93539193a6609497ccd9474); ?>
<?php endif; ?>
                            </div>
                            <div class="ct-delivery-details">
                                <div class="ct-detail"><span>Receiver</span><strong><?php echo e($trip->receiver?->name ?? 'No receiver'); ?><?php echo e($trip->receiver?->phone ? ' · ' . $trip->receiver->phone : ''); ?></strong></div>
                                <div class="ct-detail"><span>Cargo</span><strong><?php echo e($trip->product?->name ?? 'Product not available'); ?></strong></div>
                                <div class="ct-detail"><span>Condition</span><strong class="ct-condition ct-condition-<?php echo e($conditionClass); ?>"><i class="bi <?php echo e($conditionIcon); ?>"></i><?php echo e($conditionLabel); ?></strong></div>
                            </div>
                            <div class="ct-delivery-actions">
                                <?php if($trip->order): ?>
                                    <a href="<?php echo e(route('driver.orders.show', $trip->order)); ?>" class="ct-button ct-button-light ct-button-small"><i class="bi bi-eye-fill"></i>Open delivery</a>
                                <?php endif; ?>
                                <?php if($navigationUrl): ?>
                                    <a href="<?php echo e($navigationUrl); ?>" target="_blank" rel="noopener" class="ct-button ct-button-dark ct-button-small"><i class="bi bi-navigation-fill"></i>Navigate</a>
                                <?php endif; ?>
                                <?php if($trip->status === 'pending'): ?>
                                    <form method="POST" action="<?php echo e(route('driver.trips.start', $trip)); ?>">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PATCH'); ?>
                                        <input type="hidden" name="return_to" value="dashboard">
                                        <button type="submit" class="ct-button ct-button-success ct-button-small"><i class="bi bi-play-fill"></i>Start trip</button>
                                    </form>
                                <?php elseif($trip->status === 'in_progress'): ?>
                                    <form method="POST" action="<?php echo e(route('driver.trips.complete', $trip)); ?>" onsubmit="return confirm('Mark this delivery as completed?');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PATCH'); ?>
                                        <input type="hidden" name="return_to" value="dashboard">
                                        <button type="submit" class="ct-button ct-button-success ct-button-small"><i class="bi bi-check2-circle"></i>Complete trip</button>
                                    </form>
                                <?php endif; ?>
                            </div>
                        </article>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php if (isset($component)) { $__componentOriginal50f6691cb7e71446f1706a70a912a0e8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal50f6691cb7e71446f1706a70a912a0e8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.empty-state','data' => ['icon' => 'bi-check2-circle','title' => 'No current deliveries','message' => 'New assignments will appear here when an administrator assigns an order to you.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.empty-state'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => 'bi-check2-circle','title' => 'No current deliveries','message' => 'New assignments will appear here when an administrator assigns an order to you.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal50f6691cb7e71446f1706a70a912a0e8)): ?>
<?php $attributes = $__attributesOriginal50f6691cb7e71446f1706a70a912a0e8; ?>
<?php unset($__attributesOriginal50f6691cb7e71446f1706a70a912a0e8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal50f6691cb7e71446f1706a70a912a0e8)): ?>
<?php $component = $__componentOriginal50f6691cb7e71446f1706a70a912a0e8; ?>
<?php unset($__componentOriginal50f6691cb7e71446f1706a70a912a0e8); ?>
<?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
        </section>

        <aside class="ct-stack">
            <section class="ct-panel">
                <header class="ct-panel-header">
                    <div class="ct-panel-heading"><span class="ct-panel-icon cyan"><i class="bi bi-truck-front-fill"></i></span><div class="ct-panel-title"><small>Assigned equipment</small><h2>Vehicle & sensors</h2></div></div>
                </header>
                <div class="ct-panel-body">
                    <?php if($assignedTruck): ?>
                        <div class="ct-vehicle">
                            <div class="ct-vehicle-title"><span><i class="bi bi-truck-front-fill"></i></span><div><strong><?php echo e($assignedTruck->plate_number); ?></strong><small><?php echo e($assignedTruck->model ?? 'Vehicle model not set'); ?> · <?php echo e(ucfirst(str_replace('_', ' ', $assignedTruck->status))); ?></small></div></div>
                            <div class="ct-vehicle-meta">
                                <?php $__empty_1 = true; $__currentLoopData = $assignedTruck->devices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $device): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <?php $isReporting = $device->last_seen_at?->gte(now()->subMinutes(15)) ?? false; ?>
                                    <div class="ct-detail">
                                        <span><?php echo e($device->device_code); ?></span>
                                        <strong class="ct-condition ct-condition-<?php echo e($isReporting ? 'safe' : 'neutral'); ?>"><i class="bi bi-circle-fill"></i><?php echo e($isReporting ? 'Reporting now' : 'Last seen ' . ($device->last_seen_at?->diffForHumans() ?? 'never')); ?></strong>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <div class="ct-detail"><span>Sensor</span><strong>No device assigned</strong></div>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php else: ?>
                        <?php if (isset($component)) { $__componentOriginal50f6691cb7e71446f1706a70a912a0e8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal50f6691cb7e71446f1706a70a912a0e8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.empty-state','data' => ['icon' => 'bi-truck','title' => 'No truck assigned','message' => 'Contact an administrator before starting a delivery.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.empty-state'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => 'bi-truck','title' => 'No truck assigned','message' => 'Contact an administrator before starting a delivery.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal50f6691cb7e71446f1706a70a912a0e8)): ?>
<?php $attributes = $__attributesOriginal50f6691cb7e71446f1706a70a912a0e8; ?>
<?php unset($__attributesOriginal50f6691cb7e71446f1706a70a912a0e8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal50f6691cb7e71446f1706a70a912a0e8)): ?>
<?php $component = $__componentOriginal50f6691cb7e71446f1706a70a912a0e8; ?>
<?php unset($__componentOriginal50f6691cb7e71446f1706a70a912a0e8); ?>
<?php endif; ?>
                    <?php endif; ?>
                </div>
            </section>

            <?php if($openAlerts->isNotEmpty()): ?>
                <section class="ct-panel">
                    <header class="ct-panel-header">
                        <div class="ct-panel-heading"><span class="ct-panel-icon red"><i class="bi bi-exclamation-triangle-fill"></i></span><div class="ct-panel-title"><small>Act now</small><h2>Open exceptions</h2></div></div>
                    </header>
                    <div class="ct-panel-body"><div class="ct-list">
                        <?php $__currentLoopData = $openAlerts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alert): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <article class="ct-alert"><strong><span><?php echo e(ucfirst(str_replace('_', ' ', $alert->type))); ?></span><span><?php echo e(ucfirst($alert->severity)); ?></span></strong><p><?php echo e($alert->message); ?></p></article>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div></div>
                </section>
            <?php endif; ?>

            <section class="ct-panel">
                <header class="ct-panel-header">
                    <div class="ct-panel-heading"><span class="ct-panel-icon"><i class="bi bi-bell-fill"></i></span><div class="ct-panel-title"><small>Assignments</small><h2>Unread updates</h2></div></div>
                    <?php if($unreadNotificationCount > 0): ?>
                        <form method="POST" action="<?php echo e(route('driver.notifications.readAll')); ?>"><?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?><button class="ct-panel-link" type="submit">Mark all read</button></form>
                    <?php endif; ?>
                </header>
                <div class="ct-panel-body"><div class="ct-list">
                    <?php $__empty_1 = true; $__currentLoopData = $unreadOrderNotifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php $notice = $notification->data ?? []; ?>
                        <div class="ct-row-card">
                            <span class="ct-row-icon"><i class="bi bi-bell-fill"></i></span>
                            <span class="ct-row-main"><strong><?php echo e($notice['title'] ?? 'New assignment'); ?></strong><span><?php echo e($notice['message'] ?? 'An order was assigned to you.'); ?></span><small><?php echo e($notification->created_at?->diffForHumans()); ?></small></span>
                            <form method="POST" action="<?php echo e(route('driver.notifications.read', $notification->id)); ?>"><?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?><button type="submit" class="ct-button ct-button-light ct-button-small" aria-label="Mark notification read"><i class="bi bi-check2"></i></button></form>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php if (isset($component)) { $__componentOriginal50f6691cb7e71446f1706a70a912a0e8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal50f6691cb7e71446f1706a70a912a0e8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.empty-state','data' => ['icon' => 'bi-bell-slash','title' => 'You are up to date','message' => 'New assignment notifications will appear here.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.empty-state'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => 'bi-bell-slash','title' => 'You are up to date','message' => 'New assignment notifications will appear here.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal50f6691cb7e71446f1706a70a912a0e8)): ?>
<?php $attributes = $__attributesOriginal50f6691cb7e71446f1706a70a912a0e8; ?>
<?php unset($__attributesOriginal50f6691cb7e71446f1706a70a912a0e8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal50f6691cb7e71446f1706a70a912a0e8)): ?>
<?php $component = $__componentOriginal50f6691cb7e71446f1706a70a912a0e8; ?>
<?php unset($__componentOriginal50f6691cb7e71446f1706a70a912a0e8); ?>
<?php endif; ?>
                    <?php endif; ?>
                </div></div>
            </section>
        </aside>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.partials.role-dashboard-styles', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\MAURICIO\Documents\coldtrace\resources\views\driver\dashboard.blade.php ENDPATH**/ ?>