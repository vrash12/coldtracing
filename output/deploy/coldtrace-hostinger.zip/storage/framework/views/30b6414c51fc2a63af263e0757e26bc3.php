<?php
    $order = $order ?? null;
    $oldItems = old('items');

    if (!$oldItems && $order && $order->orderItems->count()) {
        $oldItems = $order->orderItems->map(function ($item) {
            return [
                'product_id' => $item->product_id,
                'quantity' => $item->quantity,
                'unit' => in_array($item->unit, ['kg', 'gram']) ? $item->unit : 'kg',
            ];
        })->toArray();
    }

    if (!$oldItems) {
        $oldItems = [
            [
                'product_id' => '',
                'quantity' => 1,
                'unit' => 'kg',
            ],
        ];
    }

    $deliveryAddress = old('delivery_address', $order?->delivery_address);
    $deliveryLat = old('delivery_lat', $order?->delivery_lat);
    $deliveryLng = old('delivery_lng', $order?->delivery_lng);
?>

<div class="order-form-wrapper">

    
    <div class="form-section-card">
        <div class="section-header">
            <div class="section-icon">
                <i class="bi bi-basket"></i>
            </div>

            <div>
                <h2>Product Information</h2>
                <p>Select the meat products included in this order. You can add more than one item.</p>
            </div>
        </div>

        <div class="order-items-card">
            <div class="order-items-header">
                <div>
                    <strong>Selected Products</strong>
                    <span>Chicken, pork, and beef orders can be measured in kilogram or gram.</span>
                </div>

                <button type="button" class="add-product-button" onclick="addOrderItem()">
                    <i class="bi bi-plus-circle"></i>
                    Add Product
                </button>
            </div>

            <div id="orderItemsList">
                <?php $__currentLoopData = $oldItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="order-item-row">
                        <div class="form-group product-field">
                            <label>Product</label>

                            <select name="items[<?php echo e($index); ?>][product_id]" required>
                                <option value="">Select product</option>

                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option
                                        value="<?php echo e($product->id); ?>"
                                        <?php echo e((string) ($item['product_id'] ?? '') === (string) $product->id ? 'selected' : ''); ?>

                                    >
                                        <?php echo e($product->name); ?> | <?php echo e($product->min_temp); ?>°C to <?php echo e($product->max_temp); ?>°C
                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="form-group quantity-field">
                            <label>Quantity</label>

                            <input
                                type="number"
                                step="0.01"
                                min="0.01"
                                name="items[<?php echo e($index); ?>][quantity]"
                                value="<?php echo e($item['quantity'] ?? 1); ?>"
                                required
                            >
                        </div>

                        <div class="form-group unit-field">
                            <label>Unit</label>

                            <?php
                                $selectedUnit = $item['unit'] ?? 'kg';

                                if (!in_array($selectedUnit, ['kg', 'gram'])) {
                                    $selectedUnit = 'kg';
                                }
                            ?>

                            <select name="items[<?php echo e($index); ?>][unit]" required>
                                <option value="kg" <?php echo e($selectedUnit === 'kg' ? 'selected' : ''); ?>>Kilogram</option>
                                <option value="gram" <?php echo e($selectedUnit === 'gram' ? 'selected' : ''); ?>>Gram</option>
                            </select>
                        </div>

                        <button type="button" class="remove-product-button" onclick="removeOrderItem(this)">
                            <i class="bi bi-trash"></i>
                        </button>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        <?php $__errorArgs = ['items'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class="error-text"><?php echo e($message); ?></small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <?php $__errorArgs = ['items.*.product_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class="error-text"><?php echo e($message); ?></small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <?php $__errorArgs = ['items.*.quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class="error-text"><?php echo e($message); ?></small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <?php $__errorArgs = ['items.*.unit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class="error-text"><?php echo e($message); ?></small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    
    <div class="form-section-card">
        <div class="section-header">
            <div class="section-icon">
                <i class="bi bi-person-check"></i>
            </div>

            <div>
                <h2>Receiver, Driver, and Schedule</h2>
                <p>Choose the customer, assign a driver, and set the expected delivery date if available.</p>
            </div>
        </div>

        <div class="form-grid compact-grid">
            <div class="form-group">
                <label for="receiver_id">Customer / Receiver</label>

                <select id="receiver_id" name="receiver_id">
                    <option value="">Select receiver</option>

                    <?php $__currentLoopData = $receivers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $receiver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option
                            value="<?php echo e($receiver->id); ?>"
                            <?php echo e((string) old('receiver_id', $order?->receiver_id) === (string) $receiver->id ? 'selected' : ''); ?>

                        >
                            <?php echo e($receiver->name); ?> - <?php echo e($receiver->email); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

                <?php $__errorArgs = ['receiver_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="error-text"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="driver_id">Assigned Driver</label>

                <select id="driver_id" name="driver_id">
                    <option value="">Select driver</option>

                    <?php $__currentLoopData = $drivers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $driver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option
                            value="<?php echo e($driver->id); ?>"
                            <?php echo e((string) old('driver_id', $order?->driver_id) === (string) $driver->id ? 'selected' : ''); ?>

                        >
                            <?php echo e($driver->name); ?> - <?php echo e($driver->email); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

                <?php $__errorArgs = ['driver_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="error-text"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="expected_delivery_at">Expected Delivery Date</label>

                <input
                    type="datetime-local"
                    id="expected_delivery_at"
                    name="expected_delivery_at"
                    value="<?php echo e(old('expected_delivery_at', $order?->expected_delivery_at?->format('Y-m-d\TH:i'))); ?>"
                >

                <?php $__errorArgs = ['expected_delivery_at'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="error-text"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
    </div>

    
    <div class="form-section-card">
        <div class="section-header">
            <div class="section-icon">
                <i class="bi bi-geo-alt"></i>
            </div>

            <div>
                <h2>Delivery Location</h2>
                <p>Search the destination or click the map to select the exact delivery point.</p>
            </div>
        </div>

        <?php if(empty($googleMapsApiKey)): ?>
            <div class="warning-box">
                Google Maps API key is missing. Please add <strong>GOOGLE_MAPS_API_KEY</strong> to your <strong>.env</strong> file.
            </div>
        <?php endif; ?>

        <div class="map-search-row">
            <div class="search-input-wrap full">
                <i class="bi bi-search"></i>
                <input
                    type="text"
                    id="delivery_search"
                    value="<?php echo e($deliveryAddress); ?>"
                    placeholder="Search delivery location..."
                >
            </div>

            <button type="button" class="map-search-button" onclick="searchDeliveryAddress()">
                Search
            </button>
        </div>

        <div class="location-picker-card">
            <div class="location-picker-header">
                <div>
                    <strong>Map Location Picker</strong>
                    <span id="selectedLocationText">
                        <?php echo e($deliveryAddress ?: 'No delivery location selected yet.'); ?>

                    </span>
                </div>
            </div>

            <div id="deliveryMap"></div>
        </div>

        <input type="hidden" id="delivery_address" name="delivery_address" value="<?php echo e($deliveryAddress); ?>">
        <input type="hidden" id="delivery_lat" name="delivery_lat" value="<?php echo e($deliveryLat); ?>">
        <input type="hidden" id="delivery_lng" name="delivery_lng" value="<?php echo e($deliveryLng); ?>">

        <?php $__errorArgs = ['delivery_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class="error-text"><?php echo e($message); ?></small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <?php $__errorArgs = ['delivery_lat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class="error-text"><?php echo e($message); ?></small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <?php $__errorArgs = ['delivery_lng'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class="error-text"><?php echo e($message); ?></small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    
    <div class="form-section-card">
        <div class="section-header">
            <div class="section-icon">
                <i class="bi bi-journal-text"></i>
            </div>

            <div>
                <h2>Handling Notes</h2>
                <p>Add special instructions for storage, loading, or delivery.</p>
            </div>
        </div>

        <div class="form-group">
            <label for="notes">Notes</label>

            <textarea
                id="notes"
                name="notes"
                rows="4"
                placeholder="Example: Keep frozen, deliver before noon, handle carefully..."
            ><?php echo e(old('notes', $order?->notes)); ?></textarea>

            <?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="error-text"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

</div>

<div class="form-actions sticky-actions">
    <button type="submit" class="primary-button">
        <?php echo e($buttonText); ?>

    </button>

    <a href="<?php echo e(route('orders.index')); ?>" class="secondary-button">
        Cancel
    </a>
</div>

<template id="orderItemTemplate">
    <div class="order-item-row">
        <div class="form-group product-field">
            <label>Product</label>

            <select data-name="product_id" required>
                <option value="">Select product</option>

                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($product->id); ?>">
                        <?php echo e($product->name); ?> | <?php echo e($product->min_temp); ?>°C to <?php echo e($product->max_temp); ?>°C
                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="form-group quantity-field">
            <label>Quantity</label>

            <input
                type="number"
                step="0.01"
                min="0.01"
                data-name="quantity"
                value="1"
                required
            >
        </div>

        <div class="form-group unit-field">
            <label>Unit</label>

            <select data-name="unit" required>
                <option value="kg">Kilogram</option>
                <option value="gram">Gram</option>
            </select>
        </div>

        <button type="button" class="remove-product-button" onclick="removeOrderItem(this)">
            <i class="bi bi-trash"></i>
        </button>
    </div>
</template>

<?php $__env->startPush('scripts'); ?>
<script>
    let orderItemIndex = <?php echo e(count($oldItems)); ?>;

    function updateOrderItemIndexes() {
        const rows = document.querySelectorAll('.order-item-row');

        rows.forEach(function (row, index) {
            row.querySelectorAll('[data-name]').forEach(function (input) {
                input.name = `items[${index}][${input.dataset.name}]`;
            });

            row.querySelectorAll('select[name], input[name]').forEach(function (input) {
                const match = input.name.match(/\[(product_id|quantity|unit)\]/);

                if (match) {
                    input.name = `items[${index}][${match[1]}]`;
                }
            });
        });

        orderItemIndex = rows.length;
    }

    function addOrderItem() {
        const template = document.getElementById('orderItemTemplate');
        const clone = template.content.cloneNode(true);

        document.getElementById('orderItemsList').appendChild(clone);
        updateOrderItemIndexes();
    }

    function removeOrderItem(button) {
        const rows = document.querySelectorAll('.order-item-row');

        if (rows.length <= 1) {
            alert('At least one product is required.');
            return;
        }

        button.closest('.order-item-row').remove();
        updateOrderItemIndexes();
    }

    let deliveryMap;
    let deliveryMarker;
    let deliveryGeocoder;
    let AdvancedMarkerElementClass;

    async function initOrderLocationPicker() {
        const mapElement = document.getElementById('deliveryMap');

        if (!mapElement || !window.google || !google.maps) {
            return;
        }

        const [{ Map }, { AdvancedMarkerElement }, { Geocoder }] = await Promise.all([
            google.maps.importLibrary('maps'),
            google.maps.importLibrary('marker'),
            google.maps.importLibrary('geocoding'),
        ]);

        AdvancedMarkerElementClass = AdvancedMarkerElement;
        deliveryGeocoder = new Geocoder();

        const defaultPosition = {
            lat: 14.5995,
            lng: 120.9842,
        };

        const existingLat = parseFloat(document.getElementById('delivery_lat').value);
        const existingLng = parseFloat(document.getElementById('delivery_lng').value);

        const hasExistingLocation = !isNaN(existingLat) && !isNaN(existingLng);

        const initialPosition = hasExistingLocation
            ? { lat: existingLat, lng: existingLng }
            : defaultPosition;

        deliveryMap = new Map(mapElement, {
            center: initialPosition,
            zoom: hasExistingLocation ? 16 : 12,
            gestureHandling: 'greedy',
            scrollwheel: true,
            mapTypeControl: false,
            streetViewControl: false,
            fullscreenControl: true,
            mapId: 'DEMO_MAP_ID',
        });

        if (hasExistingLocation) {
            placeDeliveryMarker(initialPosition);
        }

        deliveryMap.addListener('click', function (event) {
            const position = {
                lat: event.latLng.lat(),
                lng: event.latLng.lng(),
            };

            setDeliveryLocation(position, true);
        });

        attachOrderFormValidation();
    }

    function createDeliveryMarkerContent() {
        const marker = document.createElement('div');
        marker.className = 'delivery-marker';
        marker.innerHTML = '<i class="bi bi-geo-alt-fill"></i>';

        return marker;
    }

    function placeDeliveryMarker(position) {
        if (deliveryMarker) {
            deliveryMarker.position = position;
            return;
        }

        deliveryMarker = new AdvancedMarkerElementClass({
            map: deliveryMap,
            position: position,
            title: 'Delivery Location',
            content: createDeliveryMarkerContent(),
        });
    }

    function setDeliveryLocation(position, shouldReverseGeocode = false, address = null) {
        document.getElementById('delivery_lat').value = position.lat.toFixed(7);
        document.getElementById('delivery_lng').value = position.lng.toFixed(7);

        placeDeliveryMarker(position);
        deliveryMap.panTo(position);
        deliveryMap.setZoom(16);

        if (address) {
            updateDeliveryAddress(address);
            return;
        }

        if (shouldReverseGeocode) {
            reverseGeocodeDeliveryLocation(position);
        }
    }

    function updateDeliveryAddress(address) {
        document.getElementById('delivery_address').value = address;
        document.getElementById('delivery_search').value = address;
        document.getElementById('selectedLocationText').innerText = address;
    }

    function reverseGeocodeDeliveryLocation(position) {
        deliveryGeocoder.geocode({ location: position }, function (results, status) {
            if (status === 'OK' && results && results[0]) {
                updateDeliveryAddress(results[0].formatted_address);
            } else {
                const fallbackAddress = `${position.lat.toFixed(7)}, ${position.lng.toFixed(7)}`;
                updateDeliveryAddress(fallbackAddress);
            }
        });
    }

    function searchDeliveryAddress() {
        const searchInput = document.getElementById('delivery_search');
        const address = searchInput.value.trim();

        if (!address) {
            alert('Please enter a delivery location to search.');
            return;
        }

        if (!deliveryGeocoder) {
            alert('Map is still loading. Please try again.');
            return;
        }

        deliveryGeocoder.geocode({ address: address }, function (results, status) {
            if (status === 'OK' && results && results[0]) {
                const location = results[0].geometry.location;

                const position = {
                    lat: location.lat(),
                    lng: location.lng(),
                };

                setDeliveryLocation(position, false, results[0].formatted_address);
            } else {
                alert('Location not found. Please try another search term.');
            }
        });
    }

    function attachOrderFormValidation() {
        const form = document.querySelector('form');

        if (!form) {
            return;
        }

        form.addEventListener('submit', function (event) {
            const deliveryAddress = document.getElementById('delivery_address').value;
            const deliveryLat = document.getElementById('delivery_lat').value;
            const deliveryLng = document.getElementById('delivery_lng').value;

            if (!deliveryAddress || !deliveryLat || !deliveryLng) {
                event.preventDefault();
                alert('Please select a delivery location on the map before saving the order.');
            }
        });
    }

    window.initOrderLocationPicker = initOrderLocationPicker;
</script>

<?php if(!empty($googleMapsApiKey)): ?>
    <script
        async
        defer
        src="https://maps.googleapis.com/maps/api/js?key=<?php echo e($googleMapsApiKey); ?>&callback=initOrderLocationPicker&loading=async"
    ></script>
<?php endif; ?>
<?php $__env->stopPush(); ?><?php /**PATH C:\Users\MAURICIO\Documents\coldtrace\resources\views\admin\orders\partials\form.blade.php ENDPATH**/ ?>