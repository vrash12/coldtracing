<?php $__env->startSection('title', 'Edit Order'); ?>

<?php $__env->startSection('content'); ?>
<div class="customer-order-page">
    <div class="customer-order-header">
        <div>
            <span class="eyebrow">Pending order request</span>
            <h1>Edit <?php echo e($order->order_code); ?></h1>
            <p>Update the products, requested schedule, or delivery location before the order is assigned.</p>
        </div>
        <a href="<?php echo e(route('customer.orders.show', $order)); ?>" class="secondary-button">Back to order</a>
    </div>

    <?php if($errors->any()): ?>
        <div class="flash-message error">Please check the form and correct the highlighted fields.</div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('customer.orders.update', $order)); ?>" class="customer-order-form">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <?php echo $__env->make('customer.orders.partials.form', [
            'order' => $order,
            'customer' => $customer,
            'products' => $products,
            'googleMapsApiKey' => $googleMapsApiKey,
            'buttonText' => 'Save Order Changes',
            'cancelRoute' => route('customer.orders.show', $order),
        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\MAURICIO\Documents\coldtrace\resources\views\customer\orders\edit.blade.php ENDPATH**/ ?>