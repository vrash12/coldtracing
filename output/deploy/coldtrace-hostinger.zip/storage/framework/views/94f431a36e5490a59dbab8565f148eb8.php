<?php $__env->startSection('title', 'User Management'); ?>

<?php $__env->startSection('content'); ?>
<?php
    $driverRole = $roles->firstWhere('name', 'Driver');
    $receiverRole = $roles->firstWhere('name', 'Receiver');
?>

<div class="ct-index">
    <header class="ct-index-header">
        <div>
            <small>Administrator workspace</small>
            <h1>User management</h1>
            <p>Find accounts, review access, and maintain the three supported system roles from one place.</p>
        </div>
        <div class="ct-index-actions">
            <a href="<?php echo e(route('users.create')); ?>" class="ct-button ct-button-dark"><i class="bi bi-person-plus-fill"></i>Add user</a>
        </div>
    </header>

    <?php if(session('success')): ?>
        <div class="ct-flash ct-flash-success"><i class="bi bi-check-circle-fill"></i><?php echo e(session('success')); ?></div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="ct-flash ct-flash-error"><i class="bi bi-exclamation-circle-fill"></i><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    <section class="ct-metrics" aria-label="User account summary">
        <?php if (isset($component)) { $__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.metric','data' => ['label' => 'All accounts','value' => $stats['total'],'icon' => 'bi-people-fill','tone' => 'blue','href' => route('users.index')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.metric'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'All accounts','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($stats['total']),'icon' => 'bi-people-fill','tone' => 'blue','href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('users.index'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd)): ?>
<?php $attributes = $__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd; ?>
<?php unset($__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd)): ?>
<?php $component = $__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd; ?>
<?php unset($__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.metric','data' => ['label' => 'Active','value' => $stats['active'],'icon' => 'bi-person-check-fill','tone' => 'green','href' => route('users.index', ['status' => 'active'])]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.metric'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Active','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($stats['active']),'icon' => 'bi-person-check-fill','tone' => 'green','href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('users.index', ['status' => 'active']))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd)): ?>
<?php $attributes = $__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd; ?>
<?php unset($__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd)): ?>
<?php $component = $__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd; ?>
<?php unset($__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.metric','data' => ['label' => 'Drivers','value' => $stats['drivers'],'icon' => 'bi-truck-front-fill','tone' => 'cyan','href' => $driverRole ? route('users.index', ['role_id' => $driverRole->id]) : null]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.metric'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Drivers','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($stats['drivers']),'icon' => 'bi-truck-front-fill','tone' => 'cyan','href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($driverRole ? route('users.index', ['role_id' => $driverRole->id]) : null)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd)): ?>
<?php $attributes = $__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd; ?>
<?php unset($__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd)): ?>
<?php $component = $__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd; ?>
<?php unset($__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.metric','data' => ['label' => 'Customers','value' => $stats['receivers'],'icon' => 'bi-box2-heart-fill','tone' => 'violet','href' => $receiverRole ? route('users.index', ['role_id' => $receiverRole->id]) : null]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.metric'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Customers','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($stats['receivers']),'icon' => 'bi-box2-heart-fill','tone' => 'violet','href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($receiverRole ? route('users.index', ['role_id' => $receiverRole->id]) : null)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd)): ?>
<?php $attributes = $__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd; ?>
<?php unset($__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd)): ?>
<?php $component = $__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd; ?>
<?php unset($__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd); ?>
<?php endif; ?>
    </section>

    <section class="ct-panel">
        <div class="ct-filter-bar">
            <div class="ct-filter-copy">
                <strong>Accounts</strong>
                <span><?php echo e($users->total()); ?> result<?php echo e($users->total() === 1 ? '' : 's'); ?><?php echo e($search || $roleId || $status ? ' for the current filter' : ''); ?></span>
            </div>
            <form method="GET" action="<?php echo e(route('users.index')); ?>" class="ct-filter">
                <label class="ct-search">
                    <i class="bi bi-search"></i>
                    <input type="search" name="search" value="<?php echo e($search); ?>" placeholder="Name, email, or phone...">
                </label>
                <select name="role_id" aria-label="Filter by role">
                    <option value="">All roles</option>
                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($role->id); ?>" <?php echo e((string) $roleId === (string) $role->id ? 'selected' : ''); ?>><?php echo e($role->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <select name="status" aria-label="Filter by account status">
                    <option value="">All statuses</option>
                    <option value="active" <?php echo e($status === 'active' ? 'selected' : ''); ?>>Active</option>
                    <option value="inactive" <?php echo e($status === 'inactive' ? 'selected' : ''); ?>>Inactive</option>
                </select>
                <button type="submit" class="ct-button ct-button-dark ct-button-small"><i class="bi bi-funnel-fill"></i>Apply</button>
                <?php if($search || $roleId || $status): ?>
                    <a href="<?php echo e(route('users.index')); ?>" class="ct-button ct-button-light ct-button-small">Clear</a>
                <?php endif; ?>
            </form>
        </div>

        <div class="ct-panel-body ct-panel-body-flush">
            <div class="ct-table-wrap">
                <table class="ct-table">
                    <thead><tr><th>User</th><th>Role</th><th>Contact</th><th>Status</th><th>Created</th><th>Actions</th></tr></thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><strong><?php echo e($user->name); ?></strong><small><?php echo e($user->email); ?></small></td>
                                <td><?php if (isset($component)) { $__componentOriginal1f5691859226fac625a72078daa93fe3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1f5691859226fac625a72078daa93fe3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.role-badge','data' => ['role' => $user->role?->name]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.role-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['role' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($user->role?->name)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1f5691859226fac625a72078daa93fe3)): ?>
<?php $attributes = $__attributesOriginal1f5691859226fac625a72078daa93fe3; ?>
<?php unset($__attributesOriginal1f5691859226fac625a72078daa93fe3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1f5691859226fac625a72078daa93fe3)): ?>
<?php $component = $__componentOriginal1f5691859226fac625a72078daa93fe3; ?>
<?php unset($__componentOriginal1f5691859226fac625a72078daa93fe3); ?>
<?php endif; ?></td>
                                <td><strong><?php echo e($user->phone ?? 'No phone'); ?></strong></td>
                                <td><?php if (isset($component)) { $__componentOriginal41cda017b93539193a6609497ccd9474 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal41cda017b93539193a6609497ccd9474 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.status-badge','data' => ['status' => $user->status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($user->status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal41cda017b93539193a6609497ccd9474)): ?>
<?php $attributes = $__attributesOriginal41cda017b93539193a6609497ccd9474; ?>
<?php unset($__attributesOriginal41cda017b93539193a6609497ccd9474); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal41cda017b93539193a6609497ccd9474)): ?>
<?php $component = $__componentOriginal41cda017b93539193a6609497ccd9474; ?>
<?php unset($__componentOriginal41cda017b93539193a6609497ccd9474); ?>
<?php endif; ?></td>
                                <td><strong><?php echo e($user->created_at?->format('M d, Y')); ?></strong><small><?php echo e($user->created_at?->format('h:i A')); ?></small></td>
                                <td>
                                    <div class="ct-inline-actions">
                                        <a href="<?php echo e(route('users.show', $user)); ?>" class="ct-icon-button" title="View user"><i class="bi bi-eye-fill"></i></a>
                                        <a href="<?php echo e(route('users.edit', $user)); ?>" class="ct-icon-button" title="Edit user"><i class="bi bi-pencil-fill"></i></a>
                                        <?php if(auth()->id() !== $user->id): ?>
                                            <form method="POST" action="<?php echo e(route('users.destroy', $user)); ?>" onsubmit="return confirm('Delete this user account? This action cannot be undone.');">
                                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="ct-icon-button danger" title="Delete user"><i class="bi bi-trash3-fill"></i></button>
                                            </form>
                                        <?php else: ?>
                                            <span class="ct-current-user">You</span>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="6"><?php if (isset($component)) { $__componentOriginal50f6691cb7e71446f1706a70a912a0e8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal50f6691cb7e71446f1706a70a912a0e8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.empty-state','data' => ['icon' => 'bi-people','title' => 'No users found','message' => 'Clear the filters or create a new account.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.empty-state'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => 'bi-people','title' => 'No users found','message' => 'Clear the filters or create a new account.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal50f6691cb7e71446f1706a70a912a0e8)): ?>
<?php $attributes = $__attributesOriginal50f6691cb7e71446f1706a70a912a0e8; ?>
<?php unset($__attributesOriginal50f6691cb7e71446f1706a70a912a0e8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal50f6691cb7e71446f1706a70a912a0e8)): ?>
<?php $component = $__componentOriginal50f6691cb7e71446f1706a70a912a0e8; ?>
<?php unset($__componentOriginal50f6691cb7e71446f1706a70a912a0e8); ?>
<?php endif; ?></td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php if($users->hasPages()): ?><div class="ct-pagination"><?php echo e($users->links()); ?></div><?php endif; ?>
    </section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.partials.role-dashboard-styles', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('dashboard.partials.role-index-styles', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\MAURICIO\Documents\coldtrace\resources\views\admin\users\index.blade.php ENDPATH**/ ?>