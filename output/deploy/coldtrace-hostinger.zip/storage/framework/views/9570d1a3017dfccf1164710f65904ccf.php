

<?php $__env->startSection('title', 'Order Details'); ?>

<?php $__env->startSection('content'); ?>

<div class="orders-page">

    <div class="page-toolbar">
        <div>
            <h1>Order Details</h1>
        </div>

        <div class="header-actions">
            <a href="<?php echo e(route('orders.edit', $order)); ?>" class="primary-button">
                Edit Order
            </a>

            <a href="<?php echo e(route('orders.index')); ?>" class="secondary-button">
                Back to Orders
            </a>
        </div>
    </div>

    <?php if(session('success')): ?>
        <div class="flash-message success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="flash-message error">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

    <div class="details-panel">
        <div class="order-profile">
            <div class="order-icon">
                <i class="bi bi-bag-check"></i>
            </div>

            <div>
                <h2><?php echo e($order->order_code); ?></h2>

                <p>
                    <?php echo e($order->orderItems->count()); ?> product(s) in this order
                </p>

                <span class="status-badge status-<?php echo e($order->status); ?>">
                    <?php echo e(ucfirst(str_replace('_', ' ', $order->status))); ?>

                </span>
            </div>
        </div>

        <div class="details-grid">

            <div class="detail-card">
                <span>Customer / Receiver</span>
                <strong><?php echo e($order->receiver?->name ?? 'N/A'); ?></strong>
                <small><?php echo e($order->receiver?->email ?? 'N/A'); ?></small>
            </div>

            <div class="detail-card">
                <span>Assigned Driver</span>
                <strong><?php echo e($order->driver?->name ?? 'No driver assigned'); ?></strong>
                <small><?php echo e($order->driver?->email ?? 'N/A'); ?></small>
            </div>

            <div class="detail-card">
                <span>Created By</span>
                <strong><?php echo e($order->creator?->name ?? 'N/A'); ?></strong>
                <small><?php echo e($order->created_at?->format('M d, Y h:i A') ?? 'N/A'); ?></small>
            </div>

            <div class="detail-card">
                <span>Expected Delivery</span>
                <strong><?php echo e($order->expected_delivery_at?->format('M d, Y h:i A') ?? 'Not set'); ?></strong>
            </div>

            <div class="detail-card full-width">
                <span>Delivery Address</span>
                <strong><?php echo e($order->delivery_address); ?></strong>
                <small>
                    <?php echo e($order->delivery_lat ?? 'No latitude'); ?>,
                    <?php echo e($order->delivery_lng ?? 'No longitude'); ?>

                </small>
            </div>

            <div class="detail-card full-width">
                <span>Products</span>

                <?php $__empty_1 = true; $__currentLoopData = $order->orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <strong>
                        <?php echo e($item->product?->name ?? 'N/A'); ?> - <?php echo e($item->quantity); ?> <?php echo e($item->unit); ?>

                    </strong>

                    <?php if($item->product): ?>
                        <small>
                            Safe range:
                            <?php echo e($item->product->min_temp ?? 'N/A'); ?>°C
                            to
                            <?php echo e($item->product->max_temp ?? 'N/A'); ?>°C
                        </small>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <strong>No products listed</strong>
                <?php endif; ?>
            </div>

            <div class="detail-card full-width">
                <span>Notes</span>
                <strong><?php echo e($order->notes ?: 'No notes'); ?></strong>
            </div>

        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<?php echo $__env->make('admin.orders.partials.styles', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\MAURICIO\Documents\coldtrace\resources\views\admin\orders\show.blade.php ENDPATH**/ ?>