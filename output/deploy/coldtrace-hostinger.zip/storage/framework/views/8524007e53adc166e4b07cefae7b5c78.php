

<?php $__env->startSection('title', 'Edit Order'); ?>

<?php $__env->startSection('content'); ?>

<div class="orders-page">

    <div class="page-toolbar">
        <div>
            <h1>Edit Order</h1>
        </div>

        <a href="<?php echo e(route('orders.index')); ?>" class="secondary-button">
            Back to Orders
        </a>
    </div>

    <div class="form-panel">
        <form method="POST" action="<?php echo e(route('orders.update', $order)); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <?php echo $__env->make('admin.orders.partials.form', [
                'order' => $order,
                'products' => $products,
                'receivers' => $receivers,
                'buttonText' => 'Update Order',
            ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </form>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<?php echo $__env->make('admin.orders.partials.styles', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\MAURICIO\Documents\coldtrace\resources\views\admin\orders\edit.blade.php ENDPATH**/ ?>