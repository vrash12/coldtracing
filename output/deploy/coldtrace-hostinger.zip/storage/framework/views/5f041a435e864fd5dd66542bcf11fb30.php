<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['status']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['status']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $normalizedStatus = strtolower((string) $status);
    $statusIcon = match ($normalizedStatus) {
        'in_progress', 'in_transit' => 'bi-truck-front-fill',
        'active', 'completed', 'delivered' => 'bi-check-circle-fill',
        'cancelled', 'inactive' => 'bi-x-circle-fill',
        'assigned', 'approved' => 'bi-person-check-fill',
        default => 'bi-clock-fill',
    };
?>

<span class="ct-status ct-status-<?php echo e($normalizedStatus); ?>">
    <i class="bi <?php echo e($statusIcon); ?>"></i>
    <?php echo e(ucfirst(str_replace('_', ' ', $normalizedStatus))); ?>

</span>
<?php /**PATH C:\Users\MAURICIO\Documents\coldtrace\resources\views\components\dashboard\status-badge.blade.php ENDPATH**/ ?>