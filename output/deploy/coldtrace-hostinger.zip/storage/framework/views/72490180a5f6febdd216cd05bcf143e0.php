<?php $__env->startSection('title', 'Order Management'); ?>

<?php $__env->startSection('content'); ?>
<?php
    $pendingCount = (int) ($stats['pending'] ?? 0);
    $assignedCount = (int) ($stats['assigned'] ?? 0);
    $inTransitCount = (int) ($stats['in_transit'] ?? 0);
    $deliveredCount = (int) ($stats['delivered'] ?? 0);
?>

<div class="ct-index">
    <header class="ct-index-header">
        <div>
            <small>Administrator workspace</small>
            <h1>Order management</h1>
            <p>Search, assign, and review delivery orders. Fleet locations remain in the dedicated live-monitoring page.</p>
        </div>
        <div class="ct-index-actions">
            <a href="<?php echo e(route('monitoring.index')); ?>" class="ct-button ct-button-light"><i class="bi bi-map-fill"></i>Live monitoring</a>
            <a href="<?php echo e(route('orders.create')); ?>" class="ct-button ct-button-dark"><i class="bi bi-plus-circle-fill"></i>Create order</a>
        </div>
    </header>

    <?php if(session('success')): ?>
        <div class="ct-flash ct-flash-success"><i class="bi bi-check-circle-fill"></i><?php echo e(session('success')); ?></div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="ct-flash ct-flash-error"><i class="bi bi-exclamation-circle-fill"></i><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    <section class="ct-metrics" aria-label="Order status summary">
        <?php if (isset($component)) { $__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.metric','data' => ['label' => 'Awaiting assignment','value' => $pendingCount,'icon' => 'bi-hourglass-split','tone' => 'amber','href' => route('orders.index', ['status' => 'pending'])]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.metric'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Awaiting assignment','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($pendingCount),'icon' => 'bi-hourglass-split','tone' => 'amber','href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('orders.index', ['status' => 'pending']))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd)): ?>
<?php $attributes = $__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd; ?>
<?php unset($__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd)): ?>
<?php $component = $__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd; ?>
<?php unset($__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.metric','data' => ['label' => 'Assigned','value' => $assignedCount,'icon' => 'bi-person-check-fill','tone' => 'blue','href' => route('orders.index', ['status' => 'assigned'])]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.metric'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Assigned','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($assignedCount),'icon' => 'bi-person-check-fill','tone' => 'blue','href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('orders.index', ['status' => 'assigned']))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd)): ?>
<?php $attributes = $__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd; ?>
<?php unset($__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd)): ?>
<?php $component = $__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd; ?>
<?php unset($__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.metric','data' => ['label' => 'In transit','value' => $inTransitCount,'icon' => 'bi-truck-front-fill','tone' => 'cyan','href' => route('orders.index', ['status' => 'in_transit'])]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.metric'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'In transit','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($inTransitCount),'icon' => 'bi-truck-front-fill','tone' => 'cyan','href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('orders.index', ['status' => 'in_transit']))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd)): ?>
<?php $attributes = $__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd; ?>
<?php unset($__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd)): ?>
<?php $component = $__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd; ?>
<?php unset($__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.metric','data' => ['label' => 'Delivered','value' => $deliveredCount,'icon' => 'bi-check-circle-fill','tone' => 'green','href' => route('orders.index', ['status' => 'delivered'])]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.metric'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Delivered','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($deliveredCount),'icon' => 'bi-check-circle-fill','tone' => 'green','href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('orders.index', ['status' => 'delivered']))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd)): ?>
<?php $attributes = $__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd; ?>
<?php unset($__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd)): ?>
<?php $component = $__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd; ?>
<?php unset($__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd); ?>
<?php endif; ?>
    </section>

    <section class="ct-panel">
        <div class="ct-filter-bar">
            <div class="ct-filter-copy">
                <strong>Orders</strong>
                <span><?php echo e($orders->total()); ?> result<?php echo e($orders->total() === 1 ? '' : 's'); ?><?php echo e($search || $status ? ' for the current filter' : ''); ?></span>
            </div>
            <form method="GET" action="<?php echo e(route('orders.index')); ?>" class="ct-filter">
                <label class="ct-search">
                    <i class="bi bi-search"></i>
                    <input type="search" name="search" value="<?php echo e($search); ?>" placeholder="Order, customer, driver, product...">
                </label>
                <select name="status" aria-label="Filter by status">
                    <option value="">All statuses</option>
                    <?php $__currentLoopData = ['pending', 'approved', 'assigned', 'in_transit', 'delivered', 'cancelled']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $statusOption): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($statusOption); ?>" <?php echo e($status === $statusOption ? 'selected' : ''); ?>><?php echo e(ucfirst(str_replace('_', ' ', $statusOption))); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <button type="submit" class="ct-button ct-button-dark ct-button-small"><i class="bi bi-funnel-fill"></i>Apply</button>
                <?php if($search || $status): ?>
                    <a href="<?php echo e(route('orders.index')); ?>" class="ct-button ct-button-light ct-button-small">Clear</a>
                <?php endif; ?>
            </form>
        </div>

        <div class="ct-panel-body ct-panel-body-flush">
            <div class="ct-table-wrap">
                <table class="ct-table">
                    <thead><tr><th>Order</th><th>Customer</th><th>Products</th><th>Driver</th><th>Destination</th><th>Expected</th><th>Status</th><th>Actions</th></tr></thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><strong><?php echo e($order->order_code); ?></strong><small><?php echo e($order->created_at?->format('M d, Y · h:i A')); ?></small></td>
                                <td><strong><?php echo e($order->receiver?->name ?? 'No receiver'); ?></strong><small><?php echo e($order->receiver?->phone ?? $order->receiver?->email ?? 'No contact'); ?></small></td>
                                <td><div class="ct-product-list"><?php $__empty_2 = true; $__currentLoopData = $order->orderItems->take(2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?><span><?php echo e($item->product?->name ?? 'N/A'); ?></span><small><?php echo e($item->quantity); ?> <?php echo e($item->unit); ?></small><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?><span>No products</span><?php endif; ?></div></td>
                                <td><strong><?php echo e($order->driver?->name ?? 'Not assigned'); ?></strong><small><?php echo e($order->trip?->truck?->plate_number ?? 'No truck'); ?></small></td>
                                <td><span class="ct-address" title="<?php echo e($order->delivery_address); ?>"><?php echo e($order->delivery_address); ?></span></td>
                                <td><strong><?php echo e($order->expected_delivery_at?->format('M d, Y') ?? 'Not set'); ?></strong><small><?php echo e($order->expected_delivery_at?->format('h:i A')); ?></small></td>
                                <td><?php if (isset($component)) { $__componentOriginal41cda017b93539193a6609497ccd9474 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal41cda017b93539193a6609497ccd9474 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.status-badge','data' => ['status' => $order->status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($order->status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal41cda017b93539193a6609497ccd9474)): ?>
<?php $attributes = $__attributesOriginal41cda017b93539193a6609497ccd9474; ?>
<?php unset($__attributesOriginal41cda017b93539193a6609497ccd9474); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal41cda017b93539193a6609497ccd9474)): ?>
<?php $component = $__componentOriginal41cda017b93539193a6609497ccd9474; ?>
<?php unset($__componentOriginal41cda017b93539193a6609497ccd9474); ?>
<?php endif; ?></td>
                                <td>
                                    <div class="ct-inline-actions">
                                        <a href="<?php echo e(route('orders.show', $order)); ?>" class="ct-icon-button" title="View order"><i class="bi bi-eye-fill"></i></a>
                                        <?php if(! in_array($order->status, ['in_transit', 'delivered', 'cancelled'], true)): ?>
                                            <a href="<?php echo e(route('orders.edit', $order)); ?>" class="ct-icon-button" title="Edit or assign"><i class="bi bi-pencil-fill"></i></a>
                                        <?php endif; ?>
                                        <?php if($order->canBeCancelled()): ?>
                                            <form method="POST" action="<?php echo e(route('orders.cancel', $order)); ?>" onsubmit="return confirm('Cancel this order?');">
                                                <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                                <button type="submit" class="ct-icon-button warning" title="Cancel order"><i class="bi bi-x-circle-fill"></i></button>
                                            </form>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="8"><?php if (isset($component)) { $__componentOriginal50f6691cb7e71446f1706a70a912a0e8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal50f6691cb7e71446f1706a70a912a0e8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.empty-state','data' => ['icon' => 'bi-bag','title' => 'No orders found','message' => 'Try clearing the filters or create a new delivery order.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.empty-state'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => 'bi-bag','title' => 'No orders found','message' => 'Try clearing the filters or create a new delivery order.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal50f6691cb7e71446f1706a70a912a0e8)): ?>
<?php $attributes = $__attributesOriginal50f6691cb7e71446f1706a70a912a0e8; ?>
<?php unset($__attributesOriginal50f6691cb7e71446f1706a70a912a0e8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal50f6691cb7e71446f1706a70a912a0e8)): ?>
<?php $component = $__componentOriginal50f6691cb7e71446f1706a70a912a0e8; ?>
<?php unset($__componentOriginal50f6691cb7e71446f1706a70a912a0e8); ?>
<?php endif; ?></td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php if($orders->hasPages()): ?><div class="ct-pagination"><?php echo e($orders->links()); ?></div><?php endif; ?>
    </section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.partials.role-dashboard-styles', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('dashboard.partials.role-index-styles', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\MAURICIO\Documents\coldtrace\resources\views\admin\orders\index.blade.php ENDPATH**/ ?>