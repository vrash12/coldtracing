<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'label',
    'value',
    'detail' => null,
    'icon' => 'bi-activity',
    'tone' => 'blue',
    'href' => null,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'label',
    'value',
    'detail' => null,
    'icon' => 'bi-activity',
    'tone' => 'blue',
    'href' => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php if($href): ?>
    <a href="<?php echo e($href); ?>" class="ct-metric ct-tone-<?php echo e($tone); ?>">
        <span class="ct-metric-icon"><i class="bi <?php echo e($icon); ?>"></i></span>
        <span class="ct-metric-copy">
            <span><?php echo e($label); ?></span>
            <strong><?php echo e($value); ?></strong>
            <?php if($detail): ?><small><?php echo e($detail); ?></small><?php endif; ?>
        </span>
        <i class="bi bi-arrow-up-right ct-metric-arrow"></i>
    </a>
<?php else: ?>
    <article class="ct-metric ct-tone-<?php echo e($tone); ?>">
        <span class="ct-metric-icon"><i class="bi <?php echo e($icon); ?>"></i></span>
        <span class="ct-metric-copy">
            <span><?php echo e($label); ?></span>
            <strong><?php echo e($value); ?></strong>
            <?php if($detail): ?><small><?php echo e($detail); ?></small><?php endif; ?>
        </span>
    </article>
<?php endif; ?>
<?php /**PATH C:\Users\MAURICIO\Documents\coldtrace\resources\views\components\dashboard\metric.blade.php ENDPATH**/ ?>