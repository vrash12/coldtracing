<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'icon' => 'bi-inbox',
    'title' => 'Nothing to show',
    'message' => null,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'icon' => 'bi-inbox',
    'title' => 'Nothing to show',
    'message' => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<div class="ct-empty">
    <span><i class="bi <?php echo e($icon); ?>"></i></span>
    <strong><?php echo e($title); ?></strong>
    <?php if($message): ?><p><?php echo e($message); ?></p><?php endif; ?>
    <?php echo e($slot); ?>

</div>
<?php /**PATH C:\Users\MAURICIO\Documents\coldtrace\resources\views\components\dashboard\empty-state.blade.php ENDPATH**/ ?>