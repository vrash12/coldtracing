

<?php $__env->startSection('title', 'Edit User'); ?>

<?php $__env->startSection('content'); ?>

<div class="page-header">
    <div>
        <span class="eyebrow">Administrator module</span>
        <h1>Edit User</h1>
        <p>Update account details, role assignment, status, or password.</p>
    </div>

    <a href="<?php echo e(route('users.index')); ?>" class="secondary-button">
        Back to Users
    </a>
</div>

<div class="form-panel">
    <form method="POST" action="<?php echo e(route('users.update', $user)); ?>" class="user-form">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <?php echo $__env->make('admin.users.partials.form', [
            'user' => $user,
            'roles' => $roles,
            'buttonText' => 'Update User',
            'isEdit' => true,
        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </form>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<?php echo $__env->make('admin.users.partials.styles', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\MAURICIO\Documents\coldtrace\resources\views\admin\users\edit.blade.php ENDPATH**/ ?>