<?php $__env->startSection('title', 'Operations Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="ct-dashboard">
    <section class="ct-hero">
        <div class="ct-hero-copy">
            <span class="ct-eyebrow"><span class="ct-eyebrow-dot"></span>Operations overview</span>
            <h1>Focus on deliveries that need a decision.</h1>
            <p>Review dispatch workload, live fleet activity, and cold-chain exceptions from one concise operational view.</p>
            <div class="ct-hero-meta">
                <span><i class="bi bi-box-seam-fill"></i><?php echo e($activeOrders); ?> active order<?php echo e($activeOrders === 1 ? '' : 's'); ?></span>
                <span><i class="bi bi-check2-circle"></i><?php echo e($deliveredToday); ?> delivered today</span>
                <span><i class="bi bi-broadcast-pin"></i>Last sensor update: <?php echo e($latestTelemetryAt?->diffForHumans() ?? 'No readings yet'); ?></span>
            </div>
        </div>
        <div class="ct-actions">
            <a href="<?php echo e(route('orders.index')); ?>" class="ct-button ct-button-primary"><i class="bi bi-bag-check-fill"></i>Manage orders</a>
            <a href="<?php echo e(route('monitoring.index')); ?>" class="ct-button ct-button-secondary"><i class="bi bi-map-fill"></i>Live map</a>
        </div>
    </section>

    <section class="ct-metrics" aria-label="Operational summary">
        <?php if (isset($component)) { $__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.metric','data' => ['label' => 'Awaiting assignment','value' => $pendingOrders,'detail' => 'Orders without an active dispatch','icon' => 'bi-hourglass-split','tone' => 'amber','href' => route('orders.index', ['status' => 'pending'])]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.metric'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Awaiting assignment','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($pendingOrders),'detail' => 'Orders without an active dispatch','icon' => 'bi-hourglass-split','tone' => 'amber','href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('orders.index', ['status' => 'pending']))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd)): ?>
<?php $attributes = $__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd; ?>
<?php unset($__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd)): ?>
<?php $component = $__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd; ?>
<?php unset($__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.metric','data' => ['label' => 'In transit','value' => $inTransitOrders,'detail' => 'Deliveries currently moving','icon' => 'bi-truck-front-fill','tone' => 'cyan','href' => route('orders.index', ['status' => 'in_transit'])]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.metric'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'In transit','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($inTransitOrders),'detail' => 'Deliveries currently moving','icon' => 'bi-truck-front-fill','tone' => 'cyan','href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('orders.index', ['status' => 'in_transit']))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd)): ?>
<?php $attributes = $__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd; ?>
<?php unset($__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd)): ?>
<?php $component = $__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd; ?>
<?php unset($__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.metric','data' => ['label' => 'Devices reporting','value' => $reportingDevices,'detail' => $assignedDevices . ' assigned devices','icon' => 'bi-router-fill','tone' => 'green','href' => route('monitoring.index')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.metric'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Devices reporting','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($reportingDevices),'detail' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($assignedDevices . ' assigned devices'),'icon' => 'bi-router-fill','tone' => 'green','href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('monitoring.index'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd)): ?>
<?php $attributes = $__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd; ?>
<?php unset($__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd)): ?>
<?php $component = $__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd; ?>
<?php unset($__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.metric','data' => ['label' => 'Open exceptions','value' => $unresolvedAlerts,'detail' => $criticalAlerts . ' critical','icon' => 'bi-exclamation-triangle-fill','tone' => $criticalAlerts > 0 ? 'red' : 'violet','href' => route('reports.index')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.metric'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Open exceptions','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($unresolvedAlerts),'detail' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($criticalAlerts . ' critical'),'icon' => 'bi-exclamation-triangle-fill','tone' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($criticalAlerts > 0 ? 'red' : 'violet'),'href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('reports.index'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd)): ?>
<?php $attributes = $__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd; ?>
<?php unset($__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd)): ?>
<?php $component = $__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd; ?>
<?php unset($__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd); ?>
<?php endif; ?>
    </section>

    <div class="ct-grid-main">
        <section class="ct-panel">
            <header class="ct-panel-header">
                <div class="ct-panel-heading">
                    <span class="ct-panel-icon cyan"><i class="bi bi-signpost-split-fill"></i></span>
                    <div class="ct-panel-title"><small>Live operations</small><h2>Active deliveries</h2></div>
                </div>
                <a href="<?php echo e(route('monitoring.index')); ?>" class="ct-panel-link">View map <i class="bi bi-arrow-right"></i></a>
            </header>
            <div class="ct-panel-body">
                <div class="ct-delivery-list">
                    <?php $__empty_1 = true; $__currentLoopData = $activeDeliveryTrips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php
                            $reading = $trip->latestTelemetry;
                            $temperature = $reading?->temperature !== null ? (float) $reading->temperature : null;
                            $minimum = $trip->product?->min_temp !== null ? (float) $trip->product->min_temp : null;
                            $maximum = $trip->product?->max_temp !== null ? (float) $trip->product->max_temp : null;

                            if ($temperature === null || $minimum === null || $maximum === null) {
                                $conditionClass = 'neutral';
                                $conditionLabel = 'Waiting for sensor data';
                                $conditionIcon = 'bi-dash-circle';
                            } elseif ($temperature > $maximum) {
                                $conditionClass = 'danger';
                                $conditionLabel = number_format($temperature, 1) . ' °C · Above range';
                                $conditionIcon = 'bi-thermometer-high';
                            } elseif ($temperature < $minimum) {
                                $conditionClass = 'warning';
                                $conditionLabel = number_format($temperature, 1) . ' °C · Below range';
                                $conditionIcon = 'bi-thermometer-low';
                            } else {
                                $conditionClass = 'safe';
                                $conditionLabel = number_format($temperature, 1) . ' °C · In range';
                                $conditionIcon = 'bi-shield-check';
                            }
                        ?>
                        <article class="ct-delivery">
                            <div class="ct-delivery-top">
                                <div class="ct-delivery-title">
                                    <strong><?php echo e($trip->order?->order_code ?? 'Trip #' . $trip->id); ?></strong>
                                    <span><i class="bi bi-geo-alt-fill"></i> <?php echo e($trip->destination_address ?? 'Destination not set'); ?></span>
                                </div>
                                <?php if (isset($component)) { $__componentOriginal41cda017b93539193a6609497ccd9474 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal41cda017b93539193a6609497ccd9474 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.status-badge','data' => ['status' => $trip->status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($trip->status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal41cda017b93539193a6609497ccd9474)): ?>
<?php $attributes = $__attributesOriginal41cda017b93539193a6609497ccd9474; ?>
<?php unset($__attributesOriginal41cda017b93539193a6609497ccd9474); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal41cda017b93539193a6609497ccd9474)): ?>
<?php $component = $__componentOriginal41cda017b93539193a6609497ccd9474; ?>
<?php unset($__componentOriginal41cda017b93539193a6609497ccd9474); ?>
<?php endif; ?>
                            </div>
                            <div class="ct-delivery-details">
                                <div class="ct-detail"><span>Driver & truck</span><strong><?php echo e($trip->driver?->name ?? 'Unassigned'); ?> · <?php echo e($trip->truck?->plate_number ?? 'No truck'); ?></strong></div>
                                <div class="ct-detail"><span>Cargo</span><strong><?php echo e($trip->product?->name ?? 'No product'); ?></strong></div>
                                <div class="ct-detail"><span>Latest condition</span><strong class="ct-condition ct-condition-<?php echo e($conditionClass); ?>"><i class="bi <?php echo e($conditionIcon); ?>"></i><?php echo e($conditionLabel); ?></strong></div>
                            </div>
                            <div class="ct-delivery-actions">
                                <?php if($trip->order): ?>
                                    <a href="<?php echo e(route('orders.show', $trip->order)); ?>" class="ct-button ct-button-light ct-button-small"><i class="bi bi-eye-fill"></i>Open order</a>
                                <?php endif; ?>
                                <?php if($trip->latestTelemetry?->recorded_at): ?>
                                    <span class="ct-button ct-button-small" style="cursor:default;color:#64748b;background:#f8fafc;"><i class="bi bi-clock"></i><?php echo e($trip->latestTelemetry->recorded_at->diffForHumans()); ?></span>
                                <?php endif; ?>
                            </div>
                        </article>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php if (isset($component)) { $__componentOriginal50f6691cb7e71446f1706a70a912a0e8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal50f6691cb7e71446f1706a70a912a0e8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.empty-state','data' => ['icon' => 'bi-truck','title' => 'No active deliveries','message' => 'Assigned and in-transit deliveries will appear here.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.empty-state'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => 'bi-truck','title' => 'No active deliveries','message' => 'Assigned and in-transit deliveries will appear here.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal50f6691cb7e71446f1706a70a912a0e8)): ?>
<?php $attributes = $__attributesOriginal50f6691cb7e71446f1706a70a912a0e8; ?>
<?php unset($__attributesOriginal50f6691cb7e71446f1706a70a912a0e8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal50f6691cb7e71446f1706a70a912a0e8)): ?>
<?php $component = $__componentOriginal50f6691cb7e71446f1706a70a912a0e8; ?>
<?php unset($__componentOriginal50f6691cb7e71446f1706a70a912a0e8); ?>
<?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
        </section>

        <aside class="ct-stack">
            <section class="ct-panel">
                <header class="ct-panel-header">
                    <div class="ct-panel-heading">
                        <span class="ct-panel-icon amber"><i class="bi bi-exclamation-diamond-fill"></i></span>
                        <div class="ct-panel-title"><small>Action queue</small><h2>Needs attention</h2></div>
                    </div>
                </header>
                <div class="ct-panel-body">
                    <div class="ct-attention">
                        <a href="<?php echo e(route('orders.index', ['status' => 'pending'])); ?>" class="ct-attention-item">
                            <i class="bi bi-person-plus-fill"></i><span class="ct-attention-copy"><strong>Assign pending orders</strong><span>Connect each request to a driver and truck.</span></span><span class="ct-attention-count"><?php echo e($pendingOrders); ?></span>
                        </a>
                        <a href="<?php echo e(route('monitoring.index')); ?>" class="ct-attention-item <?php echo e($devicesNeedingAttention > 0 ? 'danger' : ''); ?>">
                            <i class="bi bi-router-fill"></i><span class="ct-attention-copy"><strong>Check fleet connectivity</strong><span>Assigned devices without a reading in 15 minutes.</span></span><span class="ct-attention-count"><?php echo e($devicesNeedingAttention); ?></span>
                        </a>
                        <a href="<?php echo e(route('reports.index')); ?>" class="ct-attention-item <?php echo e($criticalAlerts > 0 ? 'danger' : ''); ?>">
                            <i class="bi bi-thermometer-high"></i><span class="ct-attention-copy"><strong>Review critical exceptions</strong><span>Unresolved cold-chain events marked critical.</span></span><span class="ct-attention-count"><?php echo e($criticalAlerts); ?></span>
                        </a>
                    </div>
                </div>
            </section>

            <section class="ct-panel">
                <header class="ct-panel-header">
                    <div class="ct-panel-heading">
                        <span class="ct-panel-icon"><i class="bi bi-clock-history"></i></span>
                        <div class="ct-panel-title"><small>Dispatch queue</small><h2>Awaiting a driver</h2></div>
                    </div>
                </header>
                <div class="ct-panel-body">
                    <div class="ct-list">
                        <?php $__empty_1 = true; $__currentLoopData = $pendingAssignmentOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <a href="<?php echo e(route('orders.edit', $order)); ?>" class="ct-row-card">
                                <span class="ct-row-icon"><i class="bi bi-box-seam-fill"></i></span>
                                <span class="ct-row-main"><strong><?php echo e($order->order_code); ?></strong><span><?php echo e($order->receiver?->name ?? 'No receiver'); ?> · <?php echo e($order->delivery_address); ?></span><small>Expected <?php echo e($order->expected_delivery_at?->format('M d, h:i A') ?? 'schedule not set'); ?></small></span>
                                <i class="bi bi-chevron-right"></i>
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <?php if (isset($component)) { $__componentOriginal50f6691cb7e71446f1706a70a912a0e8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal50f6691cb7e71446f1706a70a912a0e8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.empty-state','data' => ['icon' => 'bi-check2-circle','title' => 'Dispatch queue is clear','message' => 'There are no unassigned pending orders.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.empty-state'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => 'bi-check2-circle','title' => 'Dispatch queue is clear','message' => 'There are no unassigned pending orders.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal50f6691cb7e71446f1706a70a912a0e8)): ?>
<?php $attributes = $__attributesOriginal50f6691cb7e71446f1706a70a912a0e8; ?>
<?php unset($__attributesOriginal50f6691cb7e71446f1706a70a912a0e8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal50f6691cb7e71446f1706a70a912a0e8)): ?>
<?php $component = $__componentOriginal50f6691cb7e71446f1706a70a912a0e8; ?>
<?php unset($__componentOriginal50f6691cb7e71446f1706a70a912a0e8); ?>
<?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </section>
        </aside>
    </div>

    <section class="ct-panel">
        <header class="ct-panel-header">
            <div class="ct-panel-heading"><span class="ct-panel-icon green"><i class="bi bi-receipt"></i></span><div class="ct-panel-title"><small>Latest activity</small><h2>Recent orders</h2></div></div>
            <a href="<?php echo e(route('orders.index')); ?>" class="ct-panel-link">All orders <i class="bi bi-arrow-right"></i></a>
        </header>
        <div class="ct-panel-body ct-panel-body-flush">
            <div class="ct-table-wrap">
                <table class="ct-table">
                    <thead><tr><th>Order</th><th>Receiver</th><th>Driver</th><th>Products</th><th>Expected</th><th>Status</th></tr></thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $recentOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><a href="<?php echo e(route('orders.show', $order)); ?>"><strong><?php echo e($order->order_code); ?></strong><small><?php echo e($order->created_at?->diffForHumans()); ?></small></a></td>
                                <td><?php echo e($order->receiver?->name ?? 'N/A'); ?></td>
                                <td><?php echo e($order->driver?->name ?? 'Not assigned'); ?></td>
                                <td><?php echo e($order->orderItems->pluck('product.name')->filter()->take(2)->implode(', ') ?: 'N/A'); ?></td>
                                <td><?php echo e($order->expected_delivery_at?->format('M d, h:i A') ?? 'Not set'); ?></td>
                                <td><?php if (isset($component)) { $__componentOriginal41cda017b93539193a6609497ccd9474 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal41cda017b93539193a6609497ccd9474 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.status-badge','data' => ['status' => $order->status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($order->status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal41cda017b93539193a6609497ccd9474)): ?>
<?php $attributes = $__attributesOriginal41cda017b93539193a6609497ccd9474; ?>
<?php unset($__attributesOriginal41cda017b93539193a6609497ccd9474); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal41cda017b93539193a6609497ccd9474)): ?>
<?php $component = $__componentOriginal41cda017b93539193a6609497ccd9474; ?>
<?php unset($__componentOriginal41cda017b93539193a6609497ccd9474); ?>
<?php endif; ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="6"><?php if (isset($component)) { $__componentOriginal50f6691cb7e71446f1706a70a912a0e8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal50f6691cb7e71446f1706a70a912a0e8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.empty-state','data' => ['icon' => 'bi-receipt','title' => 'No orders yet','message' => 'New order activity will appear here.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.empty-state'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => 'bi-receipt','title' => 'No orders yet','message' => 'New order activity will appear here.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal50f6691cb7e71446f1706a70a912a0e8)): ?>
<?php $attributes = $__attributesOriginal50f6691cb7e71446f1706a70a912a0e8; ?>
<?php unset($__attributesOriginal50f6691cb7e71446f1706a70a912a0e8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal50f6691cb7e71446f1706a70a912a0e8)): ?>
<?php $component = $__componentOriginal50f6691cb7e71446f1706a70a912a0e8; ?>
<?php unset($__componentOriginal50f6691cb7e71446f1706a70a912a0e8); ?>
<?php endif; ?></td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.partials.role-dashboard-styles', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\MAURICIO\Documents\coldtrace\resources\views\dashboard.blade.php ENDPATH**/ ?>