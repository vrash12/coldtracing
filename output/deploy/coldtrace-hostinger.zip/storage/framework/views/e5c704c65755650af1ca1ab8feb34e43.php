

<?php $__env->startSection('title', 'Create Order'); ?>

<?php $__env->startSection('content'); ?>

<div class="orders-page">

    <div class="page-toolbar">
        <div>
            <h1>Create Order</h1>
        </div>

        <a href="<?php echo e(route('orders.index')); ?>" class="secondary-button">
            Back to Orders
        </a>
    </div>

    <div class="form-panel">
        <form method="POST" action="<?php echo e(route('orders.store')); ?>">
            <?php echo csrf_field(); ?>

            <?php echo $__env->make('admin.orders.partials.form', [
                'order' => null,
                'products' => $products,
                'receivers' => $receivers,
                'buttonText' => 'Create Order',
            ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </form>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<?php echo $__env->make('admin.orders.partials.styles', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\MAURICIO\Documents\coldtrace\resources\views\admin\orders\create.blade.php ENDPATH**/ ?>