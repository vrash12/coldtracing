<?php $__env->startSection('title', 'Customer Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="ct-dashboard">
    <section class="ct-hero">
        <div class="ct-hero-copy">
            <span class="ct-eyebrow"><span class="ct-eyebrow-dot"></span>My deliveries</span>
            <h1>Hello, <?php echo e($customer->name); ?>. Track what matters.</h1>
            <p>See where your active deliveries stand, check cargo condition, and review your latest order requests without operational clutter.</p>
            <div class="ct-hero-meta">
                <span><i class="bi bi-geo-alt-fill"></i><?php echo e($inTransitOrders); ?> currently in transit</span>
                <span><i class="bi bi-calendar-check-fill"></i><?php echo e($scheduledOrders); ?> scheduled</span>
                <?php if($customer->permanent_delivery_address): ?>
                    <span><i class="bi bi-house-check-fill"></i>Saved delivery address available</span>
                <?php endif; ?>
            </div>
        </div>
        <div class="ct-actions">
            <a href="<?php echo e(route('customer.orders.create')); ?>" class="ct-button ct-button-primary"><i class="bi bi-plus-circle-fill"></i>Request delivery</a>
            <a href="<?php echo e(route('customer.orders.index')); ?>" class="ct-button ct-button-secondary"><i class="bi bi-box-seam-fill"></i>All orders</a>
        </div>
    </section>

    <section class="ct-metrics" aria-label="Order summary">
        <?php if (isset($component)) { $__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.metric','data' => ['label' => 'Pending review','value' => $pendingOrders,'detail' => 'Requests you can still update','icon' => 'bi-hourglass-split','tone' => 'amber','href' => route('customer.orders.index', ['status' => 'pending'])]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.metric'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Pending review','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($pendingOrders),'detail' => 'Requests you can still update','icon' => 'bi-hourglass-split','tone' => 'amber','href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('customer.orders.index', ['status' => 'pending']))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd)): ?>
<?php $attributes = $__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd; ?>
<?php unset($__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd)): ?>
<?php $component = $__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd; ?>
<?php unset($__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.metric','data' => ['label' => 'Scheduled','value' => $scheduledOrders,'detail' => 'Approved or driver assigned','icon' => 'bi-calendar2-check-fill','tone' => 'blue','href' => route('customer.orders.index')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.metric'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Scheduled','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($scheduledOrders),'detail' => 'Approved or driver assigned','icon' => 'bi-calendar2-check-fill','tone' => 'blue','href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('customer.orders.index'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd)): ?>
<?php $attributes = $__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd; ?>
<?php unset($__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd)): ?>
<?php $component = $__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd; ?>
<?php unset($__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.metric','data' => ['label' => 'In transit','value' => $inTransitOrders,'detail' => 'Deliveries on the road','icon' => 'bi-truck-front-fill','tone' => 'cyan','href' => route('customer.orders.index', ['status' => 'in_transit'])]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.metric'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'In transit','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($inTransitOrders),'detail' => 'Deliveries on the road','icon' => 'bi-truck-front-fill','tone' => 'cyan','href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('customer.orders.index', ['status' => 'in_transit']))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd)): ?>
<?php $attributes = $__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd; ?>
<?php unset($__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd)): ?>
<?php $component = $__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd; ?>
<?php unset($__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.metric','data' => ['label' => 'Delivered','value' => $deliveredOrders,'detail' => 'Successfully completed orders','icon' => 'bi-check-circle-fill','tone' => 'green','href' => route('customer.orders.index', ['status' => 'delivered'])]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.metric'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Delivered','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($deliveredOrders),'detail' => 'Successfully completed orders','icon' => 'bi-check-circle-fill','tone' => 'green','href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('customer.orders.index', ['status' => 'delivered']))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd)): ?>
<?php $attributes = $__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd; ?>
<?php unset($__attributesOriginalfe7af4a9440ac9a602e7492c1e1a9ffd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd)): ?>
<?php $component = $__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd; ?>
<?php unset($__componentOriginalfe7af4a9440ac9a602e7492c1e1a9ffd); ?>
<?php endif; ?>
    </section>

    <div class="ct-grid-main">
        <section class="ct-panel">
            <header class="ct-panel-header">
                <div class="ct-panel-heading">
                    <span class="ct-panel-icon cyan"><i class="bi bi-truck-front-fill"></i></span>
                    <div class="ct-panel-title"><small>Tracking</small><h2>Current deliveries</h2></div>
                </div>
            </header>
            <div class="ct-panel-body">
                <div class="ct-delivery-list">
                    <?php $__empty_1 = true; $__currentLoopData = $currentDeliveries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php
                            $reading = $trip->latestTelemetry;
                            $temperature = $reading?->temperature !== null ? (float) $reading->temperature : null;
                            $minimum = $trip->product?->min_temp !== null ? (float) $trip->product->min_temp : null;
                            $maximum = $trip->product?->max_temp !== null ? (float) $trip->product->max_temp : null;

                            if ($temperature === null || $minimum === null || $maximum === null) {
                                $conditionClass = 'neutral';
                                $conditionLabel = 'Waiting for cargo update';
                                $conditionIcon = 'bi-dash-circle';
                            } elseif ($temperature > $maximum || $temperature < $minimum) {
                                $conditionClass = 'warning';
                                $conditionLabel = number_format($temperature, 1) . ' °C · Outside target range';
                                $conditionIcon = 'bi-exclamation-triangle-fill';
                            } else {
                                $conditionClass = 'safe';
                                $conditionLabel = number_format($temperature, 1) . ' °C · Cargo in range';
                                $conditionIcon = 'bi-shield-check';
                            }
                        ?>
                        <article class="ct-delivery">
                            <div class="ct-delivery-top">
                                <div class="ct-delivery-title">
                                    <strong><?php echo e($trip->order?->order_code ?? 'Delivery #' . $trip->id); ?></strong>
                                    <span><i class="bi bi-geo-alt-fill"></i> <?php echo e($trip->destination_address ?? 'Destination not set'); ?></span>
                                </div>
                                <?php if (isset($component)) { $__componentOriginal41cda017b93539193a6609497ccd9474 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal41cda017b93539193a6609497ccd9474 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.status-badge','data' => ['status' => $trip->status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($trip->status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal41cda017b93539193a6609497ccd9474)): ?>
<?php $attributes = $__attributesOriginal41cda017b93539193a6609497ccd9474; ?>
<?php unset($__attributesOriginal41cda017b93539193a6609497ccd9474); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal41cda017b93539193a6609497ccd9474)): ?>
<?php $component = $__componentOriginal41cda017b93539193a6609497ccd9474; ?>
<?php unset($__componentOriginal41cda017b93539193a6609497ccd9474); ?>
<?php endif; ?>
                            </div>
                            <div class="ct-delivery-details">
                                <div class="ct-detail"><span>Driver</span><strong><?php echo e($trip->driver?->name ?? 'Waiting for assignment'); ?></strong></div>
                                <div class="ct-detail"><span>Cargo</span><strong><?php echo e($trip->product?->name ?? 'Product not available'); ?></strong></div>
                                <div class="ct-detail"><span>Condition</span><strong class="ct-condition ct-condition-<?php echo e($conditionClass); ?>"><i class="bi <?php echo e($conditionIcon); ?>"></i><?php echo e($conditionLabel); ?></strong></div>
                            </div>
                            <div class="ct-delivery-actions">
                                <?php if($trip->order): ?>
                                    <a href="<?php echo e(route('customer.orders.show', $trip->order)); ?>" class="ct-button ct-button-light ct-button-small"><i class="bi bi-eye-fill"></i>View order</a>
                                <?php endif; ?>
                                <?php if($reading?->rsl_hours !== null): ?>
                                    <span class="ct-button ct-button-small" style="cursor:default;color:#475569;background:#f8fafc;"><i class="bi bi-hourglass-bottom"></i><?php echo e(number_format((float) $reading->rsl_hours, 1)); ?> hours shelf life</span>
                                <?php endif; ?>
                                <?php if($reading?->recorded_at): ?>
                                    <span class="ct-button ct-button-small" style="cursor:default;color:#64748b;background:#f8fafc;"><i class="bi bi-clock"></i>Updated <?php echo e($reading->recorded_at->diffForHumans()); ?></span>
                                <?php endif; ?>
                            </div>
                        </article>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php if (isset($component)) { $__componentOriginal50f6691cb7e71446f1706a70a912a0e8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal50f6691cb7e71446f1706a70a912a0e8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.empty-state','data' => ['icon' => 'bi-truck','title' => 'No active deliveries','message' => 'A delivery will appear here after an administrator assigns a driver and truck.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.empty-state'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => 'bi-truck','title' => 'No active deliveries','message' => 'A delivery will appear here after an administrator assigns a driver and truck.']); ?>
                            <a href="<?php echo e(route('customer.orders.create')); ?>" class="ct-button ct-button-light ct-button-small">Create an order</a>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal50f6691cb7e71446f1706a70a912a0e8)): ?>
<?php $attributes = $__attributesOriginal50f6691cb7e71446f1706a70a912a0e8; ?>
<?php unset($__attributesOriginal50f6691cb7e71446f1706a70a912a0e8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal50f6691cb7e71446f1706a70a912a0e8)): ?>
<?php $component = $__componentOriginal50f6691cb7e71446f1706a70a912a0e8; ?>
<?php unset($__componentOriginal50f6691cb7e71446f1706a70a912a0e8); ?>
<?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
        </section>

        <aside class="ct-panel">
            <header class="ct-panel-header">
                <div class="ct-panel-heading">
                    <span class="ct-panel-icon"><i class="bi bi-clock-history"></i></span>
                    <div class="ct-panel-title"><small>Order activity</small><h2>Recent orders</h2></div>
                </div>
                <a href="<?php echo e(route('customer.orders.index')); ?>" class="ct-panel-link">View all</a>
            </header>
            <div class="ct-panel-body">
                <div class="ct-list">
                    <?php $__empty_1 = true; $__currentLoopData = $latestOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <a href="<?php echo e(route('customer.orders.show', $order)); ?>" class="ct-row-card">
                            <span class="ct-row-icon"><i class="bi bi-box-seam-fill"></i></span>
                            <span class="ct-row-main">
                                <strong><?php echo e($order->order_code); ?></strong>
                                <span><?php echo e($order->orderItems->pluck('product.name')->filter()->take(2)->implode(', ') ?: 'No product details'); ?></span>
                                <small><?php echo e($order->expected_delivery_at?->format('M d, Y · h:i A') ?? 'Delivery schedule pending'); ?></small>
                            </span>
                            <?php if (isset($component)) { $__componentOriginal41cda017b93539193a6609497ccd9474 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal41cda017b93539193a6609497ccd9474 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.status-badge','data' => ['status' => $order->status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($order->status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal41cda017b93539193a6609497ccd9474)): ?>
<?php $attributes = $__attributesOriginal41cda017b93539193a6609497ccd9474; ?>
<?php unset($__attributesOriginal41cda017b93539193a6609497ccd9474); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal41cda017b93539193a6609497ccd9474)): ?>
<?php $component = $__componentOriginal41cda017b93539193a6609497ccd9474; ?>
<?php unset($__componentOriginal41cda017b93539193a6609497ccd9474); ?>
<?php endif; ?>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php if (isset($component)) { $__componentOriginal50f6691cb7e71446f1706a70a912a0e8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal50f6691cb7e71446f1706a70a912a0e8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.empty-state','data' => ['icon' => 'bi-box-seam','title' => 'No orders yet','message' => 'Submit your first delivery request to get started.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.empty-state'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => 'bi-box-seam','title' => 'No orders yet','message' => 'Submit your first delivery request to get started.']); ?>
                            <a href="<?php echo e(route('customer.orders.create')); ?>" class="ct-button ct-button-light ct-button-small">Request delivery</a>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal50f6691cb7e71446f1706a70a912a0e8)): ?>
<?php $attributes = $__attributesOriginal50f6691cb7e71446f1706a70a912a0e8; ?>
<?php unset($__attributesOriginal50f6691cb7e71446f1706a70a912a0e8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal50f6691cb7e71446f1706a70a912a0e8)): ?>
<?php $component = $__componentOriginal50f6691cb7e71446f1706a70a912a0e8; ?>
<?php unset($__componentOriginal50f6691cb7e71446f1706a70a912a0e8); ?>
<?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
        </aside>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.partials.role-dashboard-styles', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\MAURICIO\Documents\coldtrace\resources\views\customer\dashboard.blade.php ENDPATH**/ ?>