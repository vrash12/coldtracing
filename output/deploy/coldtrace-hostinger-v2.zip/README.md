# ColdTrace

ColdTrace is a role-based cold-chain delivery monitoring system. It connects delivery orders, drivers, trips, trucks, ESP32 telemetry, temperature compliance, GPS tracking, route recommendations, and delivery reports in one Laravel application.

## What the system does

1. A customer submits a delivery order with products, destination, and schedule.
2. An administrator reviews the request, assigns a driver, and monitors operations.
3. The assigned driver plans the route and starts the trip.
4. A tracking device sends temperature and GPS readings to the telemetry API.
5. ColdTrace evaluates product temperature limits, calculates condition indicators such as MKT and remaining shelf life, and shows live trip information.
6. The driver completes the trip, while the customer and administrator can review the resulting order status.

## Supported roles

### Administrator

- Reviews operational activity from the administrator dashboard.
- Creates and maintains user accounts for the three supported roles.
- Creates, reviews, assigns, edits, and cancels orders.
- Monitors active fleet locations and temperature conditions.
- Reviews analytics and exports order or telemetry reports as CSV.

### Driver

- Reviews assigned work and notifications from the driver dashboard.
- Filters assigned orders and plans a multi-stop delivery route.
- Opens an order for navigation, telemetry, ETA, risk, MKT, and shelf-life details.
- Starts and completes assigned trips.

### Customer / Receiver

- Reviews personal delivery activity from the customer dashboard.
- Creates, edits, and cancels eligible delivery requests.
- Tracks order history, schedule, assignment, and delivery status.

## System modules

Use the following entries under **System Functionality/Features/Modules** in the Capstone 2 progress report:

1. Authentication and three-role access control
2. Administrator operations dashboard
3. User account and role management
4. Administrator order management and driver assignment
5. Customer/receiver dashboard and delivery requests
6. Customer order tracking, editing, and cancellation
7. Driver dashboard and assignment notifications
8. Driver assigned-order queue and filtering
9. Trip scheduling, start, and completion workflow
10. Multi-stop route planning and route optimization
11. AI-assisted route recommendation and risk scoring
12. Live GPS fleet monitoring map
13. ESP32/device telemetry ingestion API
14. Live temperature and product-threshold monitoring
15. Mean Kinetic Temperature (MKT) and Remaining Shelf Life (RSL) analysis
16. Cold-chain alerts and exception monitoring
17. Operational reports, charts, and CSV export
18. Responsive three-role user interface
19. System testing
20. Evaluation

## Main technology

- Laravel and PHP
- Blade templates
- MySQL in Docker; SQLite is used by the automated test environment
- Vite and JavaScript
- Google Maps for maps, navigation, and route data
- MQTT/HTTP telemetry integration for tracking devices
- Chart.js for reports

## Local development with Docker

Start the application stack:

```bash
docker compose up -d --build
```

The application is available at `http://localhost:8080`, Vite runs on port `5173`, and MySQL is exposed to the host on port `3307`.

Run Laravel commands inside the application container:

```bash
docker compose exec app php artisan migrate
docker compose exec app php artisan db:seed
docker compose run --rm test
```

Stop the environment without deleting database data:

```bash
docker compose down
```

To also remove local Docker database and dependency volumes:

```bash
docker compose down --volumes
```

> The repository contains historical placeholder migrations. Until those migrations are completed or a schema dump is provided, a brand-new database may not reproduce every table and column expected by the current application.

## Verification

```bash
php artisan view:cache
php artisan test
npm run build
```

The Vite build requires the local Node dependencies to be installed first with `npm install` or `npm ci`.
